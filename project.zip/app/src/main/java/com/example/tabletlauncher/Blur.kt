package com.example.tabletlauncher

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable

object Blur {
    fun toBitmap(d: Drawable): Bitmap {
        if (d is BitmapDrawable && d.bitmap != null) return d.bitmap
        val b = Bitmap.createBitmap(maxOf(1, d.intrinsicWidth), maxOf(1, d.intrinsicHeight), Bitmap.Config.ARGB_8888)
        val c = Canvas(b); d.setBounds(0, 0, b.width, b.height); d.draw(c)
        return b
    }

    // Scale + center-crop the source so it exactly fills w x h
    fun fitCrop(src: Bitmap, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val s = maxOf(w / src.width.toFloat(), h / src.height.toFloat())
        val m = Matrix()
        m.postScale(s, s)
        m.postTranslate((w - src.width * s) / 2f, (h - src.height * s) / 2f)
        Canvas(out).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    // Cut out a region, blur it once (software, works on every Android version)
    fun blurRegion(screen: Bitmap, x: Int, y: Int, w: Int, h: Int, k: Int = 6, radius: Int = 3): Bitmap {
        val cx = x.coerceIn(0, screen.width - 1)
        val cy = y.coerceIn(0, screen.height - 1)
        val cw = w.coerceIn(1, screen.width - cx)
        val ch = h.coerceIn(1, screen.height - cy)
        val crop = Bitmap.createBitmap(screen, cx, cy, cw, ch)
        val sw = maxOf(1, cw / k); val sh = maxOf(1, ch / k)
        val small = Bitmap.createScaledBitmap(crop, sw, sh, true).copy(Bitmap.Config.ARGB_8888, true)
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        repeat(3) { box(px, sw, sh, radius, true); box(px, sw, sh, radius, false) }
        small.setPixels(px, 0, sw, 0, 0, sw, sh)
        return Bitmap.createScaledBitmap(small, cw, ch, true)
    }

    private fun box(px: IntArray, w: Int, h: Int, r: Int, horiz: Boolean) {
        val n = if (horiz) w else h
        val lines = if (horiz) h else w
        val tmp = IntArray(n)
        for (l in 0 until lines) {
            val idx = { i: Int -> if (horiz) l * w + i else i * w + l }
            for (i in 0 until n) {
                var a = 0; var rr = 0; var g = 0; var b = 0
                for (j in -r..r) {
                    val p = px[idx((i + j).coerceIn(0, n - 1))]
                    a += p ushr 24; rr += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255
                }
                val c = 2 * r + 1
                tmp[i] = ((a / c) shl 24) or ((rr / c) shl 16) or ((g / c) shl 8) or (b / c)
            }
            for (i in 0 until n) px[idx(i)] = tmp[i]
        }
    }

    // Decode a picked image, downsampled and rotated upright according to its EXIF data
    fun decodeUpright(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sm = 1
        while (maxOf(o.outWidth, o.outHeight) / sm > maxSide) sm *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sm }
        var bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
        val orient = try {
            ctx.contentResolver.openInputStream(uri)?.use {
                android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)
            } ?: 1
        } catch (e: Exception) { 1 }
        val deg = when (orient) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
        if (deg != 0f) {
            val m = Matrix(); m.postRotate(deg)
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        return bmp
    }
}
