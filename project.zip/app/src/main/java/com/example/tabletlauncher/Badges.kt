package com.example.tabletlauncher

import android.app.Notification
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

// Shared notification counts (package name -> number of notifications)
object Badges {
    @Volatile var counts: Map<String, Int> = emptyMap()
    var onChange: (() -> Unit)? = null

    fun count(pkgs: List<String>): Int {
        var n = 0
        for (p in pkgs) n += counts[p] ?: 0
        return n
    }

    fun isEnabled(ctx: Context): Boolean {
        val s = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(ctx.packageName)
    }
}

// Needs "Notification access" to be granted once in system settings
class BadgeService : NotificationListenerService() {
    private fun refresh() {
        val m = HashMap<String, Int>()
        try {
            val list = activeNotifications
            if (list != null) for (n in list) {
                if (!n.isOngoing && (n.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0)
                    m[n.packageName] = (m[n.packageName] ?: 0) + 1
            }
        } catch (e: Exception) { }
        Badges.counts = m
        Handler(Looper.getMainLooper()).post { Badges.onChange?.invoke() }
    }

    override fun onListenerConnected() { refresh() }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { refresh() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { refresh() }
}
