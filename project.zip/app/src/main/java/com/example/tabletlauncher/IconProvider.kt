package com.example.tabletlauncher

import android.content.ComponentName
import android.content.Context
import android.content.res.Resources
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import java.io.File
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

class IconProvider(private val ctx: Context, private val prefs: Prefs) {
    private val map = HashMap<String, String>()
    private var res: Resources? = null
    private var pkg = ""

    init {
        val p = prefs.pack
        if (p.isNotEmpty()) try {
            val r = ctx.packageManager.getResourcesForApplication(p)
            res = r; pkg = p
            val id = r.getIdentifier("appfilter", "xml", p)
            val xpp: XmlPullParser
            if (id != 0) xpp = r.getXml(id) else {
                xpp = XmlPullParserFactory.newInstance().newPullParser()
                xpp.setInput(r.assets.open("appfilter.xml"), null)
            }
            val rx = Regex("ComponentInfo\\{(.+)\\}")
            var ev = xpp.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && xpp.name == "item") {
                    val c = xpp.getAttributeValue(null, "component")
                    val d = xpp.getAttributeValue(null, "drawable")
                    if (c != null && d != null) rx.find(c)?.let { map[it.groupValues[1]] = d }
                }
                ev = xpp.next()
            }
        } catch (e: Exception) { }
    }

    fun icon(cn: ComponentName, original: Drawable, sizePx: Int): Drawable {
        val cf = customIconFile(ctx, Prefs.key(cn))
        if (cf.exists()) BitmapFactory.decodeFile(cf.path)?.let { b ->
            return shaped(BitmapDrawable(ctx.resources, Bitmap.createScaledBitmap(b, sizePx, sizePx, true)), sizePx)
        }
        val name = map[Prefs.key(cn)]
        val r = res
        if (name != null && r != null) {
            val id = r.getIdentifier(name, "drawable", pkg)
            if (id != 0) try { return r.getDrawable(id, null) } catch (e: Exception) { }
        }
        return shaped(original, sizePx)
    }

    fun ratio() = when (prefs.shape) {
        "circle" -> 0.5f; "squircle" -> 0.32f; "rounded" -> 0.18f; else -> 0.04f
    }

    private fun shaped(d: Drawable, size: Int): Drawable {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (d is AdaptiveIconDrawable) {
            val p = (size * 0.25f).toInt()
            d.background?.let { it.setBounds(-p, -p, size + p, size + p); it.draw(c) }
            d.foreground?.let { it.setBounds(-p, -p, size + p, size + p); it.draw(c) }
        } else {
            d.setBounds(0, 0, size, size); d.draw(c)
            // Icon already has its own transparent corners -> keep it as designed
            if (Color.alpha(bmp.getPixel(1, 1)) < 250) return BitmapDrawable(ctx.resources, bmp)
        }
        // Erase everything OUTSIDE the chosen shape
        val rad = size * ratio()
        val outside = Path().apply {
            addRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), rad, rad, Path.Direction.CW)
            fillType = Path.FillType.INVERSE_WINDING
        }
        val clear = Paint(Paint.ANTI_ALIAS_FLAG)
        clear.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        c.drawPath(outside, clear)
        return BitmapDrawable(ctx.resources, bmp)
    }
}

fun customIconFile(ctx: Context, key: String): File =
    File(File(ctx.filesDir, "icons"), key.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".png")
