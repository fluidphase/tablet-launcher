package com.example.tabletlauncher

import android.content.ComponentName
import android.content.Context
import android.content.res.Resources
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

class IconProvider(private val ctx: Context, private val prefs: Prefs) {
    private val map = HashMap<String, String>()
    private var res: Resources? = null
    private var pkg = ""

    init {
        val p = prefs.pack
        if (p.isNotEmpty()) try {
            val r = ctx.packageManager.getResourcesForApplication(p)
            res = r; pkg = p
            val id = r.getIdentifier("appfilter", "xml", p)
            val xpp: XmlPullParser
            if (id != 0) xpp = r.getXml(id) else {
                xpp = XmlPullParserFactory.newInstance().newPullParser()
                xpp.setInput(r.assets.open("appfilter.xml"), null)
            }
            val rx = Regex("ComponentInfo\\{(.+)\\}")
            var ev = xpp.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && xpp.name == "item") {
                    val c = xpp.getAttributeValue(null, "component")
                    val d = xpp.getAttributeValue(null, "drawable")
                    if (c != null && d != null) rx.find(c)?.let { map[it.groupValues[1]] = d }
                }
                ev = xpp.next()
            }
        } catch (e: Exception) { }
    }

    fun icon(cn: ComponentName, original: Drawable, sizePx: Int): Drawable {
        val name = map[Prefs.key(cn)]
        val r = res
        if (name != null && r != null) {
            val id = r.getIdentifier(name, "drawable", pkg)
            if (id != 0) try { return r.getDrawable(id, null) } catch (e: Exception) { }
        }
        return shaped(original, sizePx)
    }

    private fun ratio() = when (prefs.shape) {
        "circle" -> 0.5f; "squircle" -> 0.32f; "rounded" -> 0.18f; else -> 0.04f
    }

    private fun shaped(d: Drawable, size: Int): Drawable {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val layer = c.saveLayer(0f, 0f, size.toFloat(), size.toFloat(), null)
        if (d is AdaptiveIconDrawable) {
            val p = (size * 0.25f).toInt()
            d.background?.let { it.setBounds(-p, -p, size + p, size + p); it.draw(c) }
            d.foreground?.let { it.setBounds(-p, -p, size + p, size + p); it.draw(c) }
        } else {
            c.drawColor(0xFF2C2C2E.toInt())
            val p = (size * 0.14f).toInt()
            d.setBounds(p, p, size - p, size - p); d.draw(c)
        }
        val mask = Paint(Paint.ANTI_ALIAS_FLAG)
        mask.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        val rad = size * ratio()
        c.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), rad, rad, mask)
        c.restoreToCount(layer)
        return BitmapDrawable(ctx.resources, bmp)
    }
}
