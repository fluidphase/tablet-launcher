package com.example.tabletlauncher

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MaxHeightScrollView(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
    }
}

// iOS-style action sheets and alerts (follows the system light/dark setting)
object Ios {
    class Item(val label: String, val destructive: Boolean = false, val action: () -> Unit)

    private class Pal(val card: Int, val text: Int, val sep: Int, val accent: Int, val red: Int,
                      val field: Int, val sub: Int, val press: Int)

    private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val EASE = PathInterpolator(0.22f, 1f, 0.36f, 1f)

    private fun pal(a: Activity): Pal {
        val dark = (a.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        return if (dark) Pal(Color.argb(244, 44, 44, 46), Color.WHITE, Color.argb(60, 255, 255, 255),
            Color.rgb(10, 132, 255), Color.rgb(255, 69, 58), Color.rgb(28, 28, 30), Color.argb(153, 235, 235, 245), Color.argb(50, 255, 255, 255))
        else Pal(Color.argb(244, 242, 242, 247), Color.BLACK, Color.argb(74, 60, 60, 67),
            Color.rgb(0, 122, 255), Color.rgb(255, 59, 48), Color.WHITE, Color.argb(153, 60, 60, 67), Color.argb(40, 60, 60, 67))
    }

    private fun dp(a: Activity, v: Int) = (v * a.resources.displayMetrics.density).toInt()
    private fun round(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = r.toFloat() }

    private fun dialog(a: Activity): Dialog {
        val d = Dialog(a, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setDimAmount(0.32f)
            if (Build.VERSION.SDK_INT >= 31) try {
                addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                val lp = attributes
                lp.blurBehindRadius = 28
                attributes = lp
            } catch (e: Exception) { }
        }
        return d
    }

    private fun hairline(a: Activity, p: Pal) = View(a).apply {
        setBackgroundColor(p.sep)
        layoutParams = LinearLayout.LayoutParams(MATCH, 1)
    }

    private fun row(a: Activity, p: Pal, label: String, color: Int, bold: Boolean, h: Int = 54, onClick: () -> Unit): TextView =
        TextView(a).apply {
            this.text = label; setTextColor(color); textSize = 19f; gravity = Gravity.CENTER
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(a, 16), 0, dp(a, 16), 0)
            background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_pressed), ColorDrawable(p.press))
                addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
            }
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(a, h))
            setOnClickListener { onClick() }
        }

    // Bottom sheet: grouped rounded list + separate bold Cancel button
    fun sheet(a: Activity, title: String?, items: List<Item>, cancel: String = "Cancel") {
        val p = pal(a); val d = dialog(a)
        val maxH = (a.resources.displayMetrics.heightPixels * 0.62f).toInt()
        val inner = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        if (title != null) inner.addView(TextView(a).apply {
            this.text = title; setTextColor(p.sub); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(dp(a, 16), dp(a, 14), dp(a, 16), dp(a, 14))
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        items.forEachIndexed { i, item ->
            if (i > 0 || title != null) inner.addView(hairline(a, p))
            inner.addView(row(a, p, item.label, if (item.destructive) p.red else p.accent, false) { d.dismiss(); item.action() })
        }
        val card = MaxHeightScrollView(a, maxH).apply {
            background = round(p.card, dp(a, 14)); clipToOutline = true; isVerticalScrollBarEnabled = false
            addView(inner)
        }
        val cancelCard = FrameLayout(a).apply {
            background = round(p.card, dp(a, 14)); clipToOutline = true
            addView(row(a, p, cancel, p.accent, true) { d.dismiss() })
        }
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, dp(8), dp(10))
        }
        root.addView(card, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(cancelCard, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(a, 8) })
        d.setContentView(root, ViewGroup.LayoutParams(MATCH, WRAP))
        d.window?.apply {
            setGravity(Gravity.BOTTOM)
            setLayout(minOf(dp(a, 392), a.resources.displayMetrics.widthPixels), WRAP)
        }
        d.show()
        root.translationY = dp(a, 420).toFloat()
        root.animate().translationY(0f).setDuration(380).setInterpolator(EASE).start()
    }

    // Centered alert with a text field and Cancel / OK
    fun input(a: Activity, title: String, message: String?, initial: String, onOk: (String) -> Unit) {
        val p = pal(a); val d = dialog(a)
        val et = EditText(a).apply {
            setText(initial); setSelection(text.length); setSingleLine()
            setTextColor(p.text); textSize = 16f
            background = round(p.field, dp(a, 8)); setPadding(dp(a, 10), dp(a, 8), dp(a, 10), dp(a, 8))
        }
        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(a, 16), dp(a, 20), dp(a, 16), dp(a, 16))
        }
        col.addView(TextView(a).apply {
            this.text = title; setTextColor(p.text); textSize = 17f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        })
        if (message != null) col.addView(TextView(a).apply {
            this.text = message; setTextColor(p.text); textSize = 13f; gravity = Gravity.CENTER; setPadding(0, dp(a, 4), 0, 0)
        })
        col.addView(et, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(a, 14) })

        val buttons = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(row(a, p, "Cancel", p.accent, false, 44) { d.dismiss() }, LinearLayout.LayoutParams(0, dp(a, 44), 1f))
        buttons.addView(View(a).apply { setBackgroundColor(p.sep) }, LinearLayout.LayoutParams(1, dp(a, 44)))
        buttons.addView(row(a, p, "OK", p.accent, true, 44) {
            val v = et.text.toString(); d.dismiss(); onOk(v)
        }, LinearLayout.LayoutParams(0, dp(a, 44), 1f))

        val card = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; background = round(p.card, dp(a, 14)); clipToOutline = true
        }
        card.addView(col)
        card.addView(hairline(a, p))
        card.addView(buttons)
        d.setContentView(card, ViewGroup.LayoutParams(MATCH, WRAP))
        d.window?.apply {
            setGravity(Gravity.CENTER)
            setLayout(dp(a, 280), WRAP)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        d.show()
        et.requestFocus()
        card.scaleX = 1.12f; card.scaleY = 1.12f; card.alpha = 0f
        card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(260).setInterpolator(EASE).start()
    }
}
