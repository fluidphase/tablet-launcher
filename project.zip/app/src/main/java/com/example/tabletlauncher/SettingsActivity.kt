package com.example.tabletlauncher

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import java.io.File
import android.view.View
import android.widget.*

class SettingsActivity : Activity() {
    private fun d(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = Prefs(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(24), d(24), d(24), d(24)) }

        fun title(t: String): TextView {
            val tv = TextView(this); tv.text = t; tv.textSize = 16f; tv.setPadding(0, d(16), 0, d(4))
            col.addView(tv); return tv
        }
        fun seek(t: String, min: Int, max: Int, cur: Int, set: (Int) -> Unit) {
            val tv = title("$t: $cur")
            val sb = SeekBar(this); sb.max = max - min; sb.progress = cur - min
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { set(v + min); tv.text = "$t: ${v + min}" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            col.addView(sb)
        }
        fun spin(t: String, names: List<String>, sel: Int, on: (Int) -> Unit) {
            title(t)
            val sp = Spinner(this)
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
            sp.setSelection(sel)
            sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) { on(pos) }
                override fun onNothingSelected(a: AdapterView<*>?) {}
            }
            col.addView(sp)
        }

        title("Tab Launcher settings (go Home to see changes)").textSize = 20f
        seek("Columns", 3, 10, p.cols) { p.cols = it }
        seek("Rows", 2, 8, p.rows) { p.rows = it }
        seek("Icon size (dp)", 40, 96, p.iconDp) { p.iconDp = it }

        val shapes = listOf("circle", "squircle", "rounded", "square")
        spin("Icon shape", shapes, shapes.indexOf(p.shape).coerceAtLeast(0)) { p.shape = shapes[it] }

        val pm = packageManager
        val packs = LinkedHashMap<String, String>()
        for (a in listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.gau.go.launcherex.theme"))
            for (ri in pm.queryIntentActivities(Intent(a), 0))
                packs[ri.activityInfo.packageName] = ri.loadLabel(pm).toString()
        val pkgs = listOf("") + packs.keys
        val names = listOf("None (system icons)") + packs.values
        spin("Icon pack", names, pkgs.indexOf(p.pack).coerceAtLeast(0)) { p.pack = pkgs[it] }

        val sw = Switch(this); sw.text = "Blurred dock"; sw.isChecked = p.blur
        sw.setOnCheckedChangeListener { _, c -> p.blur = c }
        col.addView(sw)

        val pick = Button(this); pick.text = "Choose wallpaper"
        pick.setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), 1)
        }
        col.addView(pick)
        val sys = Button(this); sys.text = "Use system wallpaper"
        sys.setOnClickListener { File(filesDir, "wall.jpg").delete(); Toast.makeText(this, "Using system wallpaper", Toast.LENGTH_SHORT).show() }
        col.addView(sys)

        val reset = Button(this); reset.text = "Reset home layout"
        reset.setOnClickListener { p.sp.edit().remove("home").remove("dock").apply(); Toast.makeText(this, "Reset", Toast.LENGTH_SHORT).show() }
        col.addView(reset)

        setContentView(ScrollView(this).apply { addView(col) })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req != 1 || res != RESULT_OK || uri == null) return
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (maxOf(o.outWidth, o.outHeight) / s > 3000) s *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = s }
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                ?: throw Exception("decode failed")
            File(filesDir, "wall.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            Toast.makeText(this, "Wallpaper saved. Go Home to see it.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't load that image", Toast.LENGTH_SHORT).show()
        }
    }
}
