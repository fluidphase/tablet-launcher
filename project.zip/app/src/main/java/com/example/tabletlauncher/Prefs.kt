package com.example.tabletlauncher

import android.content.ComponentName
import android.content.Context

class Prefs(c: Context) {
    val sp = c.getSharedPreferences("launcher", 0)
    var cols: Int get() = sp.getInt("cols", 6); set(v) { sp.edit().putInt("cols", v).apply() }
    var rows: Int get() = sp.getInt("rows", 4); set(v) { sp.edit().putInt("rows", v).apply() }
    var iconDp: Int get() = sp.getInt("iconDp", 64); set(v) { sp.edit().putInt("iconDp", v).apply() }
    var shape: String get() = sp.getString("shape", "squircle")!!; set(v) { sp.edit().putString("shape", v).apply() }
    var pack: String get() = sp.getString("pack", "")!!; set(v) { sp.edit().putString("pack", v).apply() }
    var blur: Boolean get() = sp.getBoolean("blur", true); set(v) { sp.edit().putBoolean("blur", v).apply() }
    var home: List<String> get() = sp.getString("home", "")!!.split("|"); set(v) { put("home", v) }
    var dock: List<String> get() = list("dock"); set(v) { put("dock", v) }
    private fun list(k: String) = sp.getString(k, "")!!.split("|").filter { it.isNotEmpty() }
    private fun put(k: String, v: List<String>) { sp.edit().putString(k, v.joinToString("|")).apply() }
    fun label(key: String, def: String): String = sp.getString("label_$key", null) ?: def
    fun setLabel(key: String, v: String?) {
        if (v == null) sp.edit().remove("label_$key").apply() else sp.edit().putString("label_$key", v).apply()
    }
    companion object {
        fun key(cn: ComponentName) = cn.packageName + "/" + cn.className
    }
}
