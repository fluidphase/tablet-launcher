package com.example.tabletlauncher

import android.content.ComponentName
import android.content.Context

class Prefs(c: Context) {
    val sp = c.getSharedPreferences("launcher", 0)
    var cols: Int get() = sp.getInt("cols", 6); set(v) { sp.edit().putInt("cols", v).apply() }
    var rows: Int get() = sp.getInt("rows", 4); set(v) { sp.edit().putInt("rows", v).apply() }
    var iconDp: Int get() = sp.getInt("iconDp", 64); set(v) { sp.edit().putInt("iconDp", v).apply() }
    var shape: String get() = sp.getString("shape", "squircle")!!; set(v) { sp.edit().putString("shape", v).apply() }
    var pack: String get() = sp.getString("pack", "")!!; set(v) { sp.edit().putString("pack", v).apply() }
    var blur: Boolean get() = sp.getBoolean("blur", true); set(v) { sp.edit().putBoolean("blur", v).apply() }
    var home: List<String> get() = sp.getString("home", "")!!.split("|"); set(v) { put("home", v) }
    var dock: List<String> get() = list("dock"); set(v) { put("dock", v) }
    private fun list(k: String) = sp.getString(k, "")!!.split("|").filter { it.isNotEmpty() }
    private fun put(k: String, v: List<String>) { sp.edit().putString(k, v.joinToString("|")).apply() }
    // Home-screen folders: slot content "F:<n>" refers to a folder
    fun folderName(id: String): String = sp.getString("fn_$id", "Folder")!!
    fun setFolderName(id: String, n: String) { sp.edit().putString("fn_$id", n).apply() }
    fun folderApps(id: String): List<String> = sp.getString("fa_$id", "")!!.split("|").filter { it.isNotEmpty() }
    fun setFolderApps(id: String, l: List<String>) { sp.edit().putString("fa_$id", l.joinToString("|")).apply() }
    fun newFolder(name: String, apps: List<String>): String {
        val n = sp.getInt("folder_next", 1)
        val id = "F:$n"
        sp.edit().putInt("folder_next", n + 1).putString("fn_$id", name).putString("fa_$id", apps.joinToString("|")).apply()
        return id
    }
    fun deleteFolder(id: String) { sp.edit().remove("fn_$id").remove("fa_$id").apply() }
    fun label(key: String, def: String): String = sp.getString("label_$key", null) ?: def
    fun setLabel(key: String, v: String?) {
        if (v == null) sp.edit().remove("label_$key").apply() else sp.edit().putString("label_$key", v).apply()
    }
    companion object {
        fun key(cn: ComponentName) = cn.packageName + "/" + cn.className
    }
}
