package com.example.tabletlauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.graphics.PorterDuff
import android.view.animation.DecelerateInterpolator
import java.io.File
import kotlin.math.abs

class App(val cn: ComponentName, val label: String, val orig: String, val icon: Drawable, val cat: Int) {
    val key get() = Prefs.key(cn)
}

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private lateinit var prefs: Prefs
    private lateinit var root: FrameLayout
    private lateinit var wall: ImageView
    private lateinit var grid: GridLayout
    private lateinit var homeLayer: LinearLayout
    private lateinit var wallBlur: ImageView
    private lateinit var dock: FrameLayout
    private lateinit var dockRow: LinearLayout
    private lateinit var dockBlur: ImageView
    private lateinit var library: FrameLayout
    private lateinit var libBody: LinearLayout
    private lateinit var search: EditText
    private lateinit var gd: GestureDetector
    private var apps = listOf<App>()
    private var libOpen = false
    private var wallKey = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = r.toFloat() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        prefs = Prefs(this)
        root = FrameLayout(this)
        wall = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(wall, MATCH, MATCH)
        wallBlur = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY; alpha = 0f
            setColorFilter(Color.argb(90, 0, 0, 0), PorterDuff.Mode.SRC_ATOP)
        }
        root.addView(wallBlur, MATCH, MATCH)

        homeLayer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(40), dp(24), dp(16)) }
        grid = GridLayout(this)
        grid.setOnLongClickListener { startActivity(Intent(this, SettingsActivity::class.java)); true }
        homeLayer.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))
        dock = object : FrameLayout(this) {
            override fun onMeasure(ws: Int, hs: Int) {
                dockRow.measure(MeasureSpec.makeMeasureSpec(MeasureSpec.getSize(ws), MeasureSpec.AT_MOST), hs)
                val w = maxOf(dockRow.measuredWidth, dp(80))
                val h = MeasureSpec.getSize(hs)
                setMeasuredDimension(w, h)
                val ew = MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY)
                val eh = MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY)
                dockRow.measure(ew, eh); dockBlur.measure(ew, eh)
            }
        }.apply {
            background = rounded(Color.argb(60, 255, 255, 255), dp(30))
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(30).toFloat()) }
            }
        }
        dockBlur = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_XY }
        dockRow = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(12), 0, dp(12), 0) }
        dock.addView(dockBlur, FrameLayout.LayoutParams(MATCH, MATCH))
        dock.addView(dockRow, FrameLayout.LayoutParams(MATCH, MATCH))
        homeLayer.addView(dock, LinearLayout.LayoutParams(WRAP, dp(100)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        root.addView(homeLayer, MATCH, MATCH)

        library = FrameLayout(this).apply {
            isClickable = true; visibility = View.GONE
        }
        val lib = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(48), dp(48), dp(48), dp(16)) }
        search = EditText(this).apply {
            hint = "App Library"; setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            setSingleLine(); background = rounded(Color.argb(70, 255, 255, 255), dp(14)); setPadding(dp(16), dp(10), dp(16), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { buildLibrary() }
            })
        }
        libBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lib.addView(search, MATCH, WRAP)
        lib.addView(ScrollView(this).apply { addView(libBody) }, MATCH, MATCH)
        library.addView(lib, MATCH, MATCH)
        root.addView(library, MATCH, MATCH)
        setContentView(root)

        // Swipe LEFT opens the App Library, swipe RIGHT closes it
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (abs(vx) > 800 && abs(vx) > abs(vy) * 1.5f) {
                    if (vx < 0 && !libOpen) setLibrary(true) else if (vx > 0 && libOpen) setLibrary(false)
                }
                return false
            }
        })
    }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean { gd.onTouchEvent(e); return super.dispatchTouchEvent(e) }

    override fun onResume() { super.onResume(); reload() }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); if (libOpen) setLibrary(false) }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (libOpen) setLibrary(false) }

    private fun setLibrary(open: Boolean) {
        libOpen = open
        val w = root.width.toFloat()
        val ease = DecelerateInterpolator(2f)
        val ms = 320L
        if (open) {
            library.visibility = View.VISIBLE
            library.translationX = w
            library.animate().translationX(0f).setDuration(ms).setInterpolator(ease).start()
            homeLayer.animate().translationX(-w).setDuration(ms).setInterpolator(ease).start()
            wallBlur.animate().alpha(1f).setDuration(ms).setInterpolator(ease).start()
        } else {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
            search.setText(""); search.clearFocus()
            library.animate().translationX(w).setDuration(ms).setInterpolator(ease)
                .withEndAction { library.visibility = View.GONE }.start()
            homeLayer.animate().translationX(0f).setDuration(ms).setInterpolator(ease).start()
            wallBlur.animate().alpha(0f).setDuration(ms).setInterpolator(ease).start()
        }
    }

    private fun setupWallpaper() {
        root.requestLayout()
        root.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                root.viewTreeObserver.removeOnGlobalLayoutListener(this)
                applyWallpaper()
            }
        })
    }

    // Fit wallpaper to screen once, blur the strip behind the dock once. Only redone when something changes.
    private fun applyWallpaper() {
        val w = root.width; val h = root.height
        if (w == 0 || h == 0) return
        val f = File(filesDir, "wall.jpg")
        val a = IntArray(2); val r = IntArray(2)
        dock.getLocationOnScreen(a); root.getLocationOnScreen(r)
        val dx = a[0] - r[0]; val dy = a[1] - r[1]
        val key = "${f.lastModified()}|$w|$h|$dx|$dy|${dock.width}|${dock.height}|${prefs.blur}"
        if (key == wallKey) return
        var src: Bitmap? = null
        if (f.exists()) src = BitmapFactory.decodeFile(f.path)
        if (src == null) try { src = WallpaperManager.getInstance(this).drawable?.let { Blur.toBitmap(it) } } catch (e: Exception) { }
        wallKey = key
        if (src == null) {
            wall.setImageDrawable(null); dockBlur.setImageDrawable(null)
            wallBlur.setImageDrawable(null); wallBlur.setBackgroundColor(Color.argb(200, 16, 16, 24))
            return
        }
        val screen = Blur.fitCrop(src, w, h)
        wall.setImageBitmap(screen)
        wallBlur.setBackgroundColor(0)
        wallBlur.setImageBitmap(Blur.blurRegion(screen, 0, 0, w, h, 10, 3))
        if (prefs.blur && dock.width > 0 && dock.height > 0)
            dockBlur.setImageBitmap(Blur.blurRegion(screen, dx, dy, dock.width, dock.height))
        else dockBlur.setImageDrawable(null)
    }

    private fun reload() {
        val icons = IconProvider(this, prefs)
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(q, 0).map { ri ->
            val cn = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
            val orig = ri.loadLabel(pm).toString()
            App(cn, prefs.label(Prefs.key(cn), orig), orig, icons.icon(cn, ri.loadIcon(pm), dp(prefs.iconDp)), ri.activityInfo.applicationInfo.category)
        }.sortedBy { it.label.lowercase() }
        if (!prefs.sp.contains("home")) {
            prefs.dock = apps.take(5).map { it.key }
            prefs.home = apps.drop(5).take(prefs.cols * prefs.rows).map { it.key }
        }
        buildHome(); buildLibrary()
    }

    private fun dr(a: App): Drawable = a.icon.constantState?.newDrawable() ?: a.icon

    private fun cell(a: App, label: Boolean, click: () -> Unit, long: () -> Unit): View {
        val ic = dp(prefs.iconDp)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(4), dp(4), dp(4))
            addView(ImageView(context).apply { setImageDrawable(dr(a)) }, LinearLayout.LayoutParams(ic, ic))
            if (label) addView(TextView(context).apply {
                text = a.label; setTextColor(Color.WHITE); textSize = 12f; maxLines = 1
                ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER; setShadowLayer(4f, 0f, 1f, Color.BLACK)
            })
            setOnClickListener { click() }
            setOnLongClickListener { long(); true }
        }
    }

    private fun launch(a: App) {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(a.cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun buildHome() {
        val cols = prefs.cols; val rows = prefs.rows
        grid.removeAllViews(); grid.columnCount = cols; grid.rowCount = rows
        val by = apps.associateBy { it.key }
        prefs.home.mapNotNull { by[it] }.take(cols * rows).forEachIndexed { i, a ->
            val lp = GridLayout.LayoutParams(GridLayout.spec(i / cols, 1f), GridLayout.spec(i % cols, 1f)).apply { width = 0; height = 0 }
            grid.addView(cell(a, true, { launch(a) }, { homeMenu(a) }), lp)
        }
        dock.layoutParams = (dock.layoutParams as LinearLayout.LayoutParams).apply {
            width = WRAP; height = dp(prefs.iconDp + 36); topMargin = dp(8)
        }
        dockRow.removeAllViews()
        prefs.dock.mapNotNull { by[it] }.forEach { a ->
            dockRow.addView(cell(a, false, { launch(a) }, { homeMenu(a) }), LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(8), 0, dp(8), 0) })
        }
        setupWallpaper()
    }

    private fun catName(c: Int) = when (c) {
        ApplicationInfo.CATEGORY_GAME -> "Games"
        ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> "Entertainment"
        ApplicationInfo.CATEGORY_IMAGE -> "Photo & Video"
        ApplicationInfo.CATEGORY_SOCIAL -> "Social"
        ApplicationInfo.CATEGORY_NEWS, ApplicationInfo.CATEGORY_MAPS -> "Information"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
        else -> "Other"
    }

    private fun buildLibrary() {
        libBody.removeAllViews()
        val q = search.text.toString().trim().lowercase()
        if (q.isNotEmpty()) {
            val g = GridLayout(this).apply { columnCount = prefs.cols }
            apps.filter { it.label.lowercase().contains(q) }.forEachIndexed { i, a ->
                g.addView(cell(a, true, { launch(a) }, { libMenu(a) }),
                    GridLayout.LayoutParams(GridLayout.spec(i / prefs.cols), GridLayout.spec(i % prefs.cols, 1f)).apply { width = 0 })
            }
            libBody.addView(g, MATCH, WRAP); return
        }
        val g = GridLayout(this).apply { columnCount = 4 }
        var i = 0
        for ((name, list) in apps.groupBy { catName(it.cat) }.toSortedMap()) {
            g.addView(card(name, list), GridLayout.LayoutParams(GridLayout.spec(i / 4), GridLayout.spec(i % 4, 1f)).apply {
                width = 0; setMargins(dp(12), dp(16), dp(12), dp(8))
            }); i++
        }
        libBody.addView(g, MATCH, WRAP)
    }

    private fun card(name: String, list: List<App>): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val tile = GridLayout(this).apply { columnCount = 2; setPadding(dp(8), dp(8), dp(8), dp(8)); background = rounded(Color.argb(70, 255, 255, 255), dp(26)) }
        list.take(4).forEachIndexed { i, a ->
            tile.addView(ImageView(this).apply { setImageDrawable(dr(a)) },
                GridLayout.LayoutParams(GridLayout.spec(i / 2), GridLayout.spec(i % 2)).apply { width = dp(40); height = dp(40); setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        tile.setOnClickListener { openCategory(name, list) }
        box.addView(tile, dp(112), dp(112))
        box.addView(TextView(this).apply { text = name; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) })
        return box
    }

    private fun openCategory(name: String, list: List<App>) {
        val holder = arrayOfNulls<AlertDialog>(1)
        val g = GridLayout(this).apply { columnCount = 4; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        list.forEachIndexed { i, a ->
            g.addView(cell(a, true, { holder[0]?.dismiss(); launch(a) }, { libMenu(a) }),
                GridLayout.LayoutParams(GridLayout.spec(i / 4), GridLayout.spec(i % 4, 1f)).apply { width = 0 })
        }
        holder[0] = AlertDialog.Builder(this).setTitle(name).setView(ScrollView(this).apply { addView(g) }).create()
        holder[0]!!.show()
    }

    private fun menu(a: App, items: List<Pair<String, () -> Unit>>) {
        AlertDialog.Builder(this).setTitle(a.label)
            .setItems(items.map { it.first }.toTypedArray()) { _, w -> items[w].second() }.show()
    }

    private fun info(a: App) = startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.cn.packageName)))

    private fun homeMenu(a: App) = menu(a, listOf(
        "Rename" to { rename(a) },
        "Remove from home/dock" to { prefs.home = prefs.home - a.key; prefs.dock = prefs.dock - a.key; buildHome() },
        "App info" to { info(a) }))

    private fun libMenu(a: App) = menu(a, listOf(
        "Add to home screen" to { if (a.key !in prefs.home) prefs.home = prefs.home + a.key; buildHome() },
        "Add to dock" to { if (a.key !in prefs.dock) prefs.dock = prefs.dock + a.key; buildHome() },
        "Rename" to { rename(a) },
        "App info" to { info(a) }))

    private fun rename(a: App) {
        val et = EditText(this).apply { setText(a.label); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle("Rename (empty = reset)").setView(et)
            .setPositiveButton("OK") { _, _ ->
                prefs.setLabel(a.key, et.text.toString().trim().ifEmpty { null }); reload()
            }.setNegativeButton("Cancel", null).show()
    }
}
