package com.example.tabletlauncher

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ClipData
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.graphics.PorterDuff
import android.view.animation.DecelerateInterpolator
import android.view.animation.PathInterpolator
import java.io.File
import kotlin.math.ceil
import kotlin.math.abs

class App(val cn: ComponentName, val label: String, val orig: String, val icon: Drawable, val cat: Int) {
    val key get() = Prefs.key(cn)
}

class W(val id: Int, val r: Int, val c: Int, val rs: Int, val cs: Int)

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private lateinit var prefs: Prefs
    private lateinit var root: FrameLayout
    private lateinit var wall: ImageView
    private lateinit var grid: GridLayout
    private lateinit var homeLayer: LinearLayout
    private lateinit var wallBlur: ImageView
    private lateinit var dock: FrameLayout
    private lateinit var dockRow: LinearLayout
    private lateinit var dockBlur: ImageView
    private lateinit var library: FrameLayout
    private lateinit var libBody: LinearLayout
    private lateinit var search: EditText
    private lateinit var gd: GestureDetector
    private var apps = listOf<App>()
    private var libOpen = false
    private lateinit var host: AppWidgetHost
    private lateinit var awm: AppWidgetManager
    private var pendingWidgetId = -1
    private val REQ_BIND = 41
    private val REQ_CONFIG = 42
    private lateinit var folderLayer: FrameLayout
    private lateinit var folderScrim: View
    private lateinit var folderBox: LinearLayout
    private lateinit var folderTitle: TextView
    private lateinit var folderPanel: ScrollView
    private lateinit var folderGrid: GridLayout
    private var folderOpen = false
    private var folderTile: View? = null
    private var wallKey = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = r.toFloat() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        prefs = Prefs(this)
        awm = AppWidgetManager.getInstance(this)
        host = AppWidgetHost(this, 1024)
        root = FrameLayout(this)
        wall = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(wall, MATCH, MATCH)
        wallBlur = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY; alpha = 0f
            setColorFilter(Color.argb(90, 0, 0, 0), PorterDuff.Mode.SRC_ATOP)
        }
        root.addView(wallBlur, MATCH, MATCH)

        homeLayer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(40), dp(24), dp(16)) }
        grid = GridLayout(this)
        grid.setOnLongClickListener { homeMenuEmpty(); true }
        homeLayer.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))
        dock = object : FrameLayout(this) {
            override fun onMeasure(ws: Int, hs: Int) {
                dockRow.measure(MeasureSpec.makeMeasureSpec(MeasureSpec.getSize(ws), MeasureSpec.AT_MOST), hs)
                val w = maxOf(dockRow.measuredWidth, dp(80))
                val h = MeasureSpec.getSize(hs)
                setMeasuredDimension(w, h)
                val ew = MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY)
                val eh = MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY)
                dockRow.measure(ew, eh); dockBlur.measure(ew, eh)
            }
        }.apply {
            background = rounded(Color.argb(60, 255, 255, 255), dp(30))
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(30).toFloat()) }
            }
        }
        dockBlur = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            setColorFilter(Color.argb(50, 255, 255, 255), PorterDuff.Mode.SRC_ATOP)
        }
        dockRow = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(12), 0, dp(12), 0) }
        dock.addView(dockBlur, FrameLayout.LayoutParams(MATCH, MATCH))
        dock.addView(dockRow, FrameLayout.LayoutParams(MATCH, MATCH))
        homeLayer.addView(dock, LinearLayout.LayoutParams(WRAP, dp(100)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        homeLayer.setOnDragListener(dragListener)
        root.addView(homeLayer, MATCH, MATCH)

        library = FrameLayout(this).apply {
            isClickable = true; visibility = View.GONE
        }
        val lib = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(48), dp(48), dp(48), dp(16)) }
        search = EditText(this).apply {
            hint = "App Library"; setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            setSingleLine(); background = rounded(Color.argb(70, 255, 255, 255), dp(14)); setPadding(dp(16), dp(10), dp(16), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { buildLibrary() }
            })
        }
        libBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lib.addView(search, MATCH, WRAP)
        lib.addView(ScrollView(this).apply { addView(libBody) }, MATCH, MATCH)
        library.addView(lib, MATCH, MATCH)
        root.addView(library, MATCH, MATCH)
        root.addView(buildFolderLayer(), MATCH, MATCH)
        setContentView(root)

        // Swipe LEFT opens the App Library, swipe RIGHT closes it
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (folderOpen) return false
                if (abs(vx) > 800 && abs(vx) > abs(vy) * 1.5f) {
                    if (vx < 0 && !libOpen) setLibrary(true) else if (vx > 0 && libOpen) setLibrary(false)
                }
                return false
            }
        })
    }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean { gd.onTouchEvent(e); return super.dispatchTouchEvent(e) }

    override fun onStart() { super.onStart(); try { host.startListening() } catch (e: Exception) { } }
    override fun onStop() { super.onStop(); try { host.stopListening() } catch (e: Exception) { } }

    override fun onResume() { super.onResume(); reload() }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); if (libOpen) setLibrary(false) }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (folderOpen) closeFolder(true) else if (libOpen) setLibrary(false) }

    private fun setLibrary(open: Boolean) {
        libOpen = open
        val w = root.width.toFloat()
        val ease = DecelerateInterpolator(2f)
        val ms = 320L
        if (open) {
            library.visibility = View.VISIBLE
            library.translationX = w
            library.animate().translationX(0f).setDuration(ms).setInterpolator(ease).start()
            homeLayer.animate().translationX(-w).setDuration(ms).setInterpolator(ease).start()
            wallBlur.animate().alpha(1f).setDuration(ms).setInterpolator(ease).start()
        } else {
            closeFolder(false)
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
            search.setText(""); search.clearFocus()
            library.animate().translationX(w).setDuration(ms).setInterpolator(ease)
                .withEndAction { library.visibility = View.GONE }.start()
            homeLayer.animate().translationX(0f).setDuration(ms).setInterpolator(ease).start()
            wallBlur.animate().alpha(0f).setDuration(ms).setInterpolator(ease).start()
        }
    }

    private fun setupWallpaper() {
        root.requestLayout()
        root.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                root.viewTreeObserver.removeOnGlobalLayoutListener(this)
                applyWallpaper()
            }
        })
    }

    // Fit wallpaper to screen once, blur the strip behind the dock once. Only redone when something changes.
    private fun applyWallpaper() {
        val w = root.width; val h = root.height
        if (w == 0 || h == 0) return
        val f = File(filesDir, "wall.jpg")
        val a = IntArray(2); val r = IntArray(2)
        dock.getLocationOnScreen(a); root.getLocationOnScreen(r)
        val dx = a[0] - r[0]; val dy = a[1] - r[1]
        val key = "${f.lastModified()}|$w|$h|$dx|$dy|${dock.width}|${dock.height}|${prefs.blur}"
        if (key == wallKey) return
        var src: Bitmap? = null
        if (f.exists()) src = BitmapFactory.decodeFile(f.path)
        if (src == null) try { src = WallpaperManager.getInstance(this).drawable?.let { Blur.toBitmap(it) } } catch (e: Exception) { }
        wallKey = key
        if (src == null) {
            wall.setImageDrawable(null); dockBlur.setImageDrawable(null)
            wallBlur.setImageDrawable(null); wallBlur.setBackgroundColor(Color.argb(200, 16, 16, 24))
            return
        }
        val screen = Blur.fitCrop(src, w, h)
        wall.setImageBitmap(screen)
        wallBlur.setBackgroundColor(0)
        wallBlur.setImageBitmap(Blur.blurRegion(screen, 0, 0, w, h, 10, 3))
        if (prefs.blur && dock.width > 0 && dock.height > 0)
            dockBlur.setImageBitmap(Blur.blurRegion(screen, dx, dy, dock.width, dock.height))
        else dockBlur.setImageDrawable(null)
    }

    private fun reload() {
        val icons = IconProvider(this, prefs)
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(q, 0).map { ri ->
            val cn = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
            val orig = ri.loadLabel(pm).toString()
            App(cn, prefs.label(Prefs.key(cn), orig), orig, icons.icon(cn, ri.loadIcon(pm), dp(prefs.iconDp)), ri.activityInfo.applicationInfo.category)
        }.sortedBy { it.label.lowercase() }
        if (!prefs.sp.contains("home")) {
            prefs.dock = apps.take(5).map { it.key }
            prefs.home = apps.drop(5).take(prefs.cols * prefs.rows).map { it.key }
        }
        buildHome(); buildLibrary()
    }

    private fun dr(a: App): Drawable = a.icon.constantState?.newDrawable() ?: a.icon

    private fun cell(a: App, label: Boolean, click: () -> Unit, long: (View) -> Unit): View {
        val ic = dp(prefs.iconDp)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(4), dp(4), dp(4))
            addView(ImageView(context).apply { setImageDrawable(dr(a)) }, LinearLayout.LayoutParams(ic, ic))
            if (label) addView(TextView(context).apply {
                text = a.label; setTextColor(Color.WHITE); textSize = 12f; maxLines = 1
                ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER; setShadowLayer(4f, 0f, 1f, Color.BLACK)
            })
            setOnClickListener { click() }
            setOnLongClickListener { long(this); true }
        }
    }

    private fun launch(a: App) {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(a.cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private var dragKey: String? = null
    private var pendingMenu: App? = null

    private fun slots(): MutableList<String> {
        val l = prefs.home.toMutableList()
        while (l.size < prefs.cols * prefs.rows) l.add("")
        return l
    }

    private fun removeFromHome(key: String) { prefs.home = prefs.home.map { if (it == key) "" else it } }

    private fun addToHome(key: String) {
        val sl = slots()
        if (key in sl) return
        val cov = coveredSlots()
        val e = sl.indices.firstOrNull { sl[it].isEmpty() && it !in cov } ?: -1
        if (e < 0) { Toast.makeText(this, "Home screen is full", Toast.LENGTH_SHORT).show(); return }
        sl[e] = key; prefs.home = sl
    }

    // Long-press = pick up the icon. Drop it back where it was to get the menu.
    private fun startDrag(v: View, a: App) {
        dragKey = a.key
        v.alpha = 0.3f
        v.startDragAndDrop(ClipData.newPlainText("app", a.key), View.DragShadowBuilder(v), null, 0)
    }

    private val dragListener = View.OnDragListener { _, e ->
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED -> dragKey != null
            DragEvent.ACTION_DROP -> { handleDrop(e.x, e.y); true }
            DragEvent.ACTION_DRAG_ENDED -> {
                dragKey = null
                buildHome()
                pendingMenu?.let { pendingMenu = null; homeMenu(it) }
                true
            }
            else -> true
        }
    }

    private fun handleDrop(x: Float, y: Float) {
        val key = dragKey ?: return
        val a = apps.find { it.key == key } ?: return
        val cols = prefs.cols; val rows = prefs.rows
        val present = apps.map { it.key }.toSet()
        val sl = slots()
        val oldSlot = sl.indexOf(key)
        val dockList = prefs.dock.filter { it in present }.toMutableList()
        val oldDock = dockList.indexOf(key)

        if (y >= dock.top - dp(16)) {
            // dropped on the dock: insert by horizontal position
            var idx = 0
            for (i in 0 until dockRow.childCount) {
                val c = dockRow.getChildAt(i)
                val l = dock.left + c.left; val r = dock.left + c.right
                if (i == oldDock && x >= l && x <= r) { pendingMenu = a; return }
                if (i != oldDock && (l + r) / 2f < x) idx++
            }
            dockList.remove(key)
            if (dockList.size >= 8) { Toast.makeText(this, "Dock is full", Toast.LENGTH_SHORT).show(); return }
            dockList.add(idx.coerceAtMost(dockList.size), key)
            prefs.dock = dockList
            if (oldSlot >= 0) { sl[oldSlot] = ""; prefs.home = sl }
        } else if (y >= grid.top && y < grid.bottom) {
            val col = ((x - grid.left) * cols / grid.width).toInt().coerceIn(0, cols - 1)
            val row = ((y - grid.top) * rows / grid.height).toInt().coerceIn(0, rows - 1)
            val t = row * cols + col
            if (t in coveredSlots()) return
            if (t == oldSlot) { pendingMenu = a; return }
            val other = sl[t]
            sl[t] = key
            if (oldSlot >= 0) sl[oldSlot] = other          // swap with whatever was there (or leave a gap)
            if (oldDock >= 0) {
                dockList.remove(key)
                if (other.isNotEmpty()) dockList.add(oldDock.coerceAtMost(dockList.size), other)
                prefs.dock = dockList
            }
            prefs.home = sl
        }
    }

    // ---------------- Widgets ----------------
    private fun widgets(): MutableList<W> =
        prefs.sp.getString("widgets", "")!!.split(";").filter { it.isNotEmpty() }.mapNotNull {
            val p = it.split(",")
            if (p.size == 5) W(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toInt(), p[4].toInt()) else null
        }.toMutableList()

    private fun saveWidgets(l: List<W>) {
        prefs.sp.edit().putString("widgets", l.joinToString(";") { "${it.id},${it.r},${it.c},${it.rs},${it.cs}" }).apply()
    }

    private fun coveredSlots(): Set<Int> {
        val s = HashSet<Int>(); val cols = prefs.cols; val rows = prefs.rows
        for (w in widgets()) for (r in w.r until minOf(rows, w.r + w.rs)) for (c in w.c until minOf(cols, w.c + w.cs)) s.add(r * cols + c)
        return s
    }

    private fun homeMenuEmpty() {
        AlertDialog.Builder(this).setItems(arrayOf("Add widget", "Launcher settings")) { _, w ->
            if (w == 0) pickWidget() else startActivity(Intent(this, SettingsActivity::class.java))
        }.show()
    }

    private fun widgetMenu(w: W) {
        AlertDialog.Builder(this).setItems(arrayOf("Resize", "Remove widget")) { _, i ->
            if (i == 1) {
                host.deleteAppWidgetId(w.id)
                saveWidgets(widgets().filter { it.id != w.id }); buildHome()
            } else resizeWidget(w)
        }.show()
    }

    private fun resizeWidget(w: W) {
        AlertDialog.Builder(this).setTitle("Width (columns)")
            .setItems((1..prefs.cols).map { it.toString() }.toTypedArray()) { _, i ->
                AlertDialog.Builder(this).setTitle("Height (rows)")
                    .setItems((1..prefs.rows).map { it.toString() }.toTypedArray()) { _, j ->
                        placeWidget(w.id, j + 1, i + 1, w.r, w.c); buildHome()
                    }.show()
            }.show()
    }

    private fun pickWidget() {
        val pm = packageManager
        val list = awm.installedProviders.sortedBy { it.loadLabel(pm).lowercase() }
        val names = list.map { it.loadLabel(pm) + "  \u2022  " + it.provider.packageName.substringAfterLast('.') }
        AlertDialog.Builder(this).setTitle("Add widget")
            .setItems(names.toTypedArray()) { _, i -> startBind(list[i]) }.show()
    }

    private fun startBind(info: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pendingWidgetId = id
        try {
            if (awm.bindAppWidgetIdIfAllowed(id, info.provider)) afterBind(id)
            else startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider), REQ_BIND)
        } catch (e: Exception) { cancelWidget() }
    }

    private fun afterBind(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info?.configure != null) {
            try { host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null) }
            catch (e: Exception) { finishWidget(id) }
        } else finishWidget(id)
    }

    private fun finishWidget(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info == null) { cancelWidget(); return }
        val cols = prefs.cols; val rows = prefs.rows
        var rs: Int; var cs: Int
        if (Build.VERSION.SDK_INT >= 31 && info.targetCellWidth > 0 && info.targetCellHeight > 0) {
            rs = info.targetCellHeight; cs = info.targetCellWidth
        } else {
            val cw = grid.width / cols.toFloat(); val ch = grid.height / rows.toFloat()
            cs = ceil(info.minWidth / cw.toDouble()).toInt(); rs = ceil(info.minHeight / ch.toDouble()).toInt()
        }
        pendingWidgetId = -1
        placeWidget(id, rs, cs); buildHome()
    }

    private fun cancelWidget() {
        if (pendingWidgetId != -1) host.deleteAppWidgetId(pendingWidgetId)
        pendingWidgetId = -1
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val id = pendingWidgetId
        if (req == REQ_BIND) { if (res == RESULT_OK && id != -1) afterBind(id) else cancelWidget() }
        else if (req == REQ_CONFIG) { if (res == RESULT_OK && id != -1) finishWidget(id) else cancelWidget() }
    }

    // Find room for a widget (first free spot, pushing apps out of its way), then save it
    private fun placeWidget(id: Int, rs0: Int, cs0: Int, pr: Int = -1, pc: Int = -1) {
        val cols = prefs.cols; val rows = prefs.rows
        val rs = rs0.coerceIn(1, rows); val cs = cs0.coerceIn(1, cols)
        val others = widgets().filter { it.id != id }
        val taken = HashSet<Int>()
        for (w in others) for (r in w.r until minOf(rows, w.r + w.rs)) for (c in w.c until minOf(cols, w.c + w.cs)) taken.add(r * cols + c)
        val sl = slots()
        fun fits(r: Int, c: Int, needEmpty: Boolean): Boolean {
            if (r + rs > rows || c + cs > cols) return false
            for (rr in r until r + rs) for (cc in c until c + cs) {
                val i = rr * cols + cc
                if (i in taken) return false
                if (needEmpty && sl[i].isNotEmpty()) return false
            }
            return true
        }
        var pos: Pair<Int, Int>? = null
        if (pr >= 0 && fits(pr, pc, false)) pos = pr to pc
        if (pos == null) search@ for (need in listOf(true, false)) for (r in 0 until rows) for (c in 0 until cols)
            if (fits(r, c, need)) { pos = r to c; break@search }
        if (pos == null) {
            Toast.makeText(this, "No room for that widget", Toast.LENGTH_SHORT).show()
            if (widgets().none { it.id == id }) host.deleteAppWidgetId(id)
            return
        }
        val rect = HashSet<Int>()
        for (rr in pos.first until pos.first + rs) for (cc in pos.second until pos.second + cs) rect.add(rr * cols + cc)
        for (i in rect) if (sl[i].isNotEmpty()) {
            val j = sl.indices.firstOrNull { sl[it].isEmpty() && it !in rect && it !in taken }
            if (j != null) { sl[j] = sl[i]; sl[i] = "" }
        }
        saveWidgets(others + W(id, pos.first, pos.second, rs, cs))
        prefs.home = sl
    }

    private fun buildHome() {
        val cols = prefs.cols; val rows = prefs.rows
        grid.removeAllViews(); grid.columnCount = cols; grid.rowCount = rows
        val by = apps.associateBy { it.key }
        val covered = coveredSlots()
        prefs.home.take(cols * rows).forEachIndexed { i, key ->
            if (i in covered) return@forEachIndexed
            val a = by[key] ?: return@forEachIndexed
            val lp = GridLayout.LayoutParams(GridLayout.spec(i / cols, 1f), GridLayout.spec(i % cols, 1f)).apply { width = 0; height = 0 }
            grid.addView(cell(a, true, { launch(a) }, { v -> startDrag(v, a) }), lp)
        }
        for (w in widgets()) {
            if (w.r >= rows || w.c >= cols) continue
            val info = awm.getAppWidgetInfo(w.id) ?: continue
            val hv = host.createView(this, w.id, info)
            hv.setOnLongClickListener { widgetMenu(w); true }
            hv.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
                val d = resources.displayMetrics.density
                val wd = ((r - l) / d).toInt(); val hd = ((b - t) / d).toInt()
                if (hv.tag != "$wd,$hd") { hv.tag = "$wd,$hd"; hv.updateAppWidgetSize(null, wd, hd, wd, hd) }
            }
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(w.r, minOf(w.rs, rows - w.r), 1f), GridLayout.spec(w.c, minOf(w.cs, cols - w.c), 1f)
            ).apply { width = 0; height = 0; setMargins(dp(6), dp(6), dp(6), dp(6)) }
            grid.addView(hv, lp)
        }
        dock.layoutParams = (dock.layoutParams as LinearLayout.LayoutParams).apply {
            width = WRAP; height = dp(prefs.iconDp + 36); topMargin = dp(8)
        }
        dockRow.removeAllViews()
        prefs.dock.mapNotNull { by[it] }.forEach { a ->
            dockRow.addView(cell(a, false, { launch(a) }, { v -> startDrag(v, a) }), LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(8), 0, dp(8), 0) })
        }
        setupWallpaper()
    }

    private val catOrder = listOf("Utilities", "Settings", "Media", "Video", "Communication", "Games")

    // Android's own app categories are unreliable, so we also match on package name / label.
    private fun catName(a: App): String {
        val p = a.cn.packageName.lowercase(); val l = a.orig.lowercase()
        fun has(vararg k: String) = k.any { p.contains(it) || l.contains(it) }
        return when {
            has("settings") -> "Settings"
            a.cat == ApplicationInfo.CATEGORY_GAME -> "Games"
            a.cat == ApplicationInfo.CATEGORY_SOCIAL ||
                has("dialer", "phone", "contacts", "message", "sms", "mms", "mail", "messenger", "whatsapp",
                    "telegram", "discord", "signal", "viber", "chat", "meet", "zoom", "skype") -> "Communication"
            a.cat == ApplicationInfo.CATEGORY_VIDEO ||
                has("video", "youtube", "netflix", "twitch", "tiktok", "movie") -> "Video"
            a.cat == ApplicationInfo.CATEGORY_AUDIO || a.cat == ApplicationInfo.CATEGORY_IMAGE ||
                has("music", "audio", "podcast", "spotify", "gallery", "photo", "camera", "recorder", "radio") -> "Media"
            else -> "Utilities"
        }
    }

    private fun buildLibrary() {
        closeFolder(false)
        libBody.removeAllViews()
        val q = search.text.toString().trim().lowercase()
        if (q.isNotEmpty()) {
            val g = GridLayout(this).apply { columnCount = prefs.cols }
            apps.filter { it.label.lowercase().contains(q) }.forEachIndexed { i, a ->
                g.addView(cell(a, true, { launch(a) }, { libMenu(a) }),
                    GridLayout.LayoutParams(GridLayout.spec(i / prefs.cols), GridLayout.spec(i % prefs.cols, 1f)).apply { width = 0 })
            }
            libBody.addView(g, MATCH, WRAP); return
        }
        val g = GridLayout(this).apply { columnCount = 4 }
        var i = 0
        val groups = apps.groupBy { catName(it) }
        for ((name, list) in catOrder.mapNotNull { n -> groups[n]?.let { n to it } }) {
            g.addView(card(name, list), GridLayout.LayoutParams(GridLayout.spec(i / 4), GridLayout.spec(i % 4, 1f)).apply {
                width = 0; setMargins(dp(12), dp(16), dp(12), dp(8))
            }); i++
        }
        libBody.addView(g, MATCH, WRAP)
    }

    private fun card(name: String, list: List<App>): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val tile = GridLayout(this).apply { columnCount = 2; setPadding(dp(8), dp(8), dp(8), dp(8)); background = rounded(Color.argb(70, 255, 255, 255), dp(26)) }
        list.take(4).forEachIndexed { i, a ->
            tile.addView(ImageView(this).apply { setImageDrawable(dr(a)) },
                GridLayout.LayoutParams(GridLayout.spec(i / 2), GridLayout.spec(i % 2)).apply { width = dp(40); height = dp(40); setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        tile.setOnClickListener { openCategory(name, list, tile) }
        box.addView(tile, dp(112), dp(112))
        box.addView(TextView(this).apply { text = name; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) })
        return box
    }

    private fun buildFolderLayer(): View {
        folderLayer = FrameLayout(this).apply { visibility = View.GONE }
        folderScrim = View(this).apply {
            setBackgroundColor(Color.argb(110, 0, 0, 0)); alpha = 0f
            setOnClickListener { closeFolder(true) }
        }
        folderLayer.addView(folderScrim, MATCH, MATCH)
        folderTitle = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 30f; gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(20))
        }
        folderPanel = ScrollView(this).apply {
            background = rounded(Color.argb(70, 255, 255, 255), dp(34))
            isClickable = true
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        folderGrid = GridLayout(this).apply { columnCount = 4 }
        folderPanel.addView(folderGrid)
        folderBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; alpha = 0f }
        folderBox.addView(folderTitle, WRAP, WRAP)
        folderBox.addView(folderPanel, LinearLayout.LayoutParams(dp(200), dp(200)))
        folderLayer.addView(folderBox, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        return folderLayer
    }

    private fun openCategory(name: String, list: List<App>, tile: View) {
        if (folderOpen) return
        folderTile?.alpha = 1f
        folderOpen = true; folderTile = tile
        folderTitle.text = name
        val cw = dp(104)
        folderGrid.removeAllViews()
        list.forEachIndexed { i, a ->
            folderGrid.addView(cell(a, true, { closeFolder(false); launch(a) }, { libMenu(a) }),
                GridLayout.LayoutParams(GridLayout.spec(i / 4), GridLayout.spec(i % 4)).apply { width = cw })
        }
        val rowsN = maxOf(2, (list.size + 3) / 4)
        val ph = minOf(rowsN * dp(prefs.iconDp + 44) + dp(32), (root.height * 0.65f).toInt())
        folderPanel.layoutParams = LinearLayout.LayoutParams(4 * cw + dp(32), ph)
        folderPanel.scrollTo(0, 0)
        folderBox.animate().cancel(); folderScrim.animate().cancel()
        folderBox.alpha = 0f
        folderLayer.visibility = View.VISIBLE
        folderBox.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                folderBox.viewTreeObserver.removeOnGlobalLayoutListener(this)
                animateFolder(true)
            }
        })
    }

    // The tapped folder tile zooms into the big panel (and back), ease-out.
    private fun animateFolder(open: Boolean) {
        val tile = folderTile ?: return
        val t = IntArray(2); val r = IntArray(2)
        tile.getLocationOnScreen(t); folderLayer.getLocationOnScreen(r)
        val tcx = t[0] - r[0] + tile.width / 2f
        val tcy = t[1] - r[1] + tile.height / 2f
        folderBox.pivotX = folderPanel.left + folderPanel.width / 2f
        folderBox.pivotY = folderPanel.top + folderPanel.height / 2f
        val bcx = folderBox.left + folderBox.pivotX
        val bcy = folderBox.top + folderBox.pivotY
        val s = tile.width / folderPanel.width.toFloat()
        val ease = PathInterpolator(0.22f, 1f, 0.36f, 1f)   // smooth ease-out
        if (open) {
            folderBox.scaleX = s; folderBox.scaleY = s
            folderBox.translationX = tcx - bcx; folderBox.translationY = tcy - bcy
            folderBox.alpha = 0f
            tile.alpha = 0f
            folderBox.animate().scaleX(1f).scaleY(1f).translationX(0f).translationY(0f).alpha(1f)
                .setDuration(380).setInterpolator(ease).withLayer().start()
            folderScrim.animate().alpha(1f).setDuration(380).setInterpolator(ease).withLayer().start()
        } else {
            folderBox.animate().scaleX(s).scaleY(s).translationX(tcx - bcx).translationY(tcy - bcy).alpha(0f)
                .setDuration(300).setInterpolator(ease).withLayer()
                .withEndAction { folderLayer.visibility = View.GONE; tile.alpha = 1f }.start()
            folderScrim.animate().alpha(0f).setDuration(300).setInterpolator(ease).withLayer().start()
        }
    }

    private fun closeFolder(animate: Boolean) {
        if (!folderOpen) return
        folderOpen = false
        if (animate) animateFolder(false) else {
            folderBox.animate().cancel(); folderScrim.animate().cancel()
            folderLayer.visibility = View.GONE
            folderBox.alpha = 0f; folderScrim.alpha = 0f
            folderTile?.alpha = 1f
        }
    }

    private fun menu(a: App, items: List<Pair<String, () -> Unit>>) {
        AlertDialog.Builder(this).setTitle(a.label)
            .setItems(items.map { it.first }.toTypedArray()) { _, w -> items[w].second() }.show()
    }

    private fun info(a: App) = startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.cn.packageName)))

    private fun homeMenu(a: App) = menu(a, listOf(
        "Rename" to { rename(a) },
        "Remove from home/dock" to { removeFromHome(a.key); prefs.dock = prefs.dock - a.key; buildHome() },
        "App info" to { info(a) }))

    private fun libMenu(a: App) = menu(a, listOf(
        "Add to home screen" to { addToHome(a.key); buildHome() },
        "Add to dock" to { removeFromHome(a.key); if (a.key !in prefs.dock) prefs.dock = prefs.dock + a.key; buildHome() },
        "Rename" to { rename(a) },
        "App info" to { info(a) }))

    private fun rename(a: App) {
        val et = EditText(this).apply { setText(a.label); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle("Rename (empty = reset)").setView(et)
            .setPositiveButton("OK") { _, _ ->
                prefs.setLabel(a.key, et.text.toString().trim().ifEmpty { null }); reload()
            }.setNegativeButton("Cancel", null).show()
    }
}
