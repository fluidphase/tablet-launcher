package com.example.tabletlauncher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.ActivityOptions
import android.app.SearchManager
import android.graphics.Typeface
import android.view.inputmethod.EditorInfo
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ClipData
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.animation.OvershootInterpolator
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.graphics.PorterDuff
import android.view.animation.DecelerateInterpolator
import android.view.animation.PathInterpolator
import java.io.File
import kotlin.math.ceil
import kotlin.math.abs
import kotlin.random.Random

class App(val cn: ComponentName, val label: String, val orig: String, val icon: Drawable, val cat: Int) {
    val key get() = Prefs.key(cn)
}

// Rounded rect that can be morphed from the folder tile to the big panel
class MorphBg(ctx: Context) : View(ctx) {
    val rect = RectF()
    var radius = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 255, 255, 255) }
    override fun onDraw(c: Canvas) { c.drawRoundRect(rect, radius, radius, paint) }
}

// Pan + pinch-zoom square cropper for custom icons
class CropView(ctx: Context) : View(ctx) {
    private var bmp: Bitmap? = null
    private var s = 1f; private var tx = 0f; private var ty = 0f; private var minS = 1f
    private val crop = RectF()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val dim = Paint().apply { color = Color.argb(160, 0, 0, 0) }
    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f }
    private var lx = 0f; private var ly = 0f
    private val sgd = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val ns = (s * d.scaleFactor).coerceIn(minS, minS * 8f)
            val f = ns / s
            tx = d.focusX - (d.focusX - tx) * f; ty = d.focusY - (d.focusY - ty) * f
            s = ns; clamp(); invalidate()
            return true
        }
    })

    fun setBitmap(b: Bitmap) { bmp = b; layoutCrop(); resetFit(); invalidate() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { layoutCrop(); if (bmp != null) resetFit() }

    private fun layoutCrop() {
        val side = minOf(width, height) * 0.8f
        crop.set((width - side) / 2f, (height - side) / 2f, (width + side) / 2f, (height + side) / 2f)
    }

    private fun resetFit() {
        val b = bmp ?: return
        if (crop.width() <= 0f) return
        minS = crop.width() / minOf(b.width, b.height)
        s = minS
        tx = crop.centerX() - b.width * s / 2f; ty = crop.centerY() - b.height * s / 2f
        clamp()
    }

    private fun clamp() {
        val b = bmp ?: return
        val w = b.width * s; val h = b.height * s
        tx = tx.coerceIn(minOf(crop.right - w, crop.left), crop.left)
        ty = ty.coerceIn(minOf(crop.bottom - h, crop.top), crop.top)
    }

    override fun onDraw(c: Canvas) {
        val b = bmp ?: return
        c.save(); c.translate(tx, ty); c.scale(s, s); c.drawBitmap(b, 0f, 0f, paint); c.restore()
        val w = width.toFloat(); val h = height.toFloat()
        c.drawRect(0f, 0f, w, crop.top, dim); c.drawRect(0f, crop.bottom, w, h, dim)
        c.drawRect(0f, crop.top, crop.left, crop.bottom, dim); c.drawRect(crop.right, crop.top, w, crop.bottom, dim)
        c.drawRect(crop, frame)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sgd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y }
            MotionEvent.ACTION_POINTER_UP -> { val i = if (e.actionIndex == 0) 1 else 0; lx = e.getX(i); ly = e.getY(i) }
            MotionEvent.ACTION_MOVE -> if (!sgd.isInProgress && e.pointerCount == 1) {
                tx += e.x - lx; ty += e.y - ly; clamp(); invalidate(); lx = e.x; ly = e.y
            }
        }
        return true
    }

    fun result(size: Int): Bitmap? {
        val b = bmp ?: return null
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out); val k = size / crop.width()
        c.scale(k, k); c.translate(-crop.left, -crop.top); c.translate(tx, ty); c.scale(s, s)
        c.drawBitmap(b, 0f, 0f, paint)
        return out
    }
}

// Widget container that detects a long-press even when the widget itself swallows touches
class WidgetWrap(ctx: Context) : FrameLayout(ctx) {
    var onLongPress: (() -> Unit)? = null
    private var x0 = 0f; private var y0 = 0f
    private var fired = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val fire = Runnable { fired = true; onLongPress?.invoke() }
    init { clipChildren = false }

    private fun track(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                fired = false; x0 = e.rawX; y0 = e.rawY
                if (onLongPress != null) postDelayed(fire, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> if (!fired && (abs(e.rawX - x0) > slop || abs(e.rawY - y0) > slop)) removeCallbacks(fire)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> removeCallbacks(fire)
        }
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean { track(e); return fired }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked != MotionEvent.ACTION_DOWN) track(e)
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) fired = false
        return true
    }
}

// Edit-mode overlay on a widget: drag the side handles to resize (snaps to the grid), drag elsewhere to move
class WidgetEditOverlay(ctx: Context) : View(ctx) {
    var onMove: ((Float, Float) -> Unit)? = null
    var onResizeStart: (() -> Unit)? = null
    var onResizeDrag: ((Int, Float, Float) -> Unit)? = null
    var onResizeEnd: (() -> Unit)? = null
    private val d = ctx.resources.displayMetrics.density
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * d; color = Color.argb(200, 255, 255, 255) }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * d; color = Color.argb(160, 0, 0, 0) }
    private var mode = 0          // 0 none, 1 pending move, 2 moving, 3 resizing
    private var handle = -1       // 0 left, 1 top, 2 right, 3 bottom
    private var x0 = 0f; private var y0 = 0f

    private fun centers(): Array<FloatArray> {
        val i = 10f * d
        return arrayOf(floatArrayOf(i, height / 2f), floatArrayOf(width / 2f, i),
            floatArrayOf(width - i, height / 2f), floatArrayOf(width / 2f, height - i))
    }

    override fun onDraw(c: Canvas) {
        c.drawRoundRect(RectF(d, d, width - d, height - d), 14f * d, 14f * d, border)
        for (p in centers()) { c.drawCircle(p[0], p[1], 8f * d, fill); c.drawCircle(p[0], p[1], 8f * d, ring) }
    }

    private fun hit(x: Float, y: Float): Int {
        var best = -1; var bd = 32f * d
        centers().forEachIndexed { i, p ->
            val dist = Math.hypot((x - p[0]).toDouble(), (y - p[1]).toDouble()).toFloat()
            if (dist < bd) { bd = dist; best = i }
        }
        return best
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                x0 = e.rawX; y0 = e.rawY
                handle = hit(e.x, e.y)
                if (handle >= 0) { mode = 3; parent?.requestDisallowInterceptTouchEvent(true); onResizeStart?.invoke() } else mode = 1
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 3) onResizeDrag?.invoke(handle, e.rawX, e.rawY)
                else if (mode == 1 && (abs(e.rawX - x0) > slop || abs(e.rawY - y0) > slop)) {
                    mode = 2; parent?.requestDisallowInterceptTouchEvent(true); onMove?.invoke(e.x, e.y)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { if (mode == 3) onResizeEnd?.invoke(); mode = 0 }
        }
        return true
    }
}

// iOS-style red notification badge shown on the corner of an icon
class CountBadge(ctx: Context, val pkgs: List<String>) : TextView(ctx) {
    init {
        val d = ctx.resources.displayMetrics.density
        setTextColor(Color.WHITE); textSize = 11f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        minWidth = (20 * d).toInt(); minHeight = (20 * d).toInt()
        setPadding((5 * d).toInt(), 0, (5 * d).toInt(), 0)
        background = GradientDrawable().apply { setColor(Color.rgb(255, 59, 48)); cornerRadius = 10f * d }
        update()
    }

    fun update() {
        val n = Badges.count(pkgs)
        if (n <= 0) visibility = View.GONE
        else { text = if (n > 99) "99+" else n.toString(); visibility = View.VISIBLE }
    }
}

class W(val id: Int, val r: Int, val c: Int, val rs: Int, val cs: Int)

class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private lateinit var prefs: Prefs
    private lateinit var root: FrameLayout
    private lateinit var wall: ImageView
    private lateinit var grid: GridLayout
    private lateinit var homeLayer: LinearLayout
    private lateinit var wallBlur: ImageView
    private lateinit var dock: FrameLayout
    private lateinit var dockRow: LinearLayout
    private lateinit var dockBlur: ImageView
    private lateinit var library: FrameLayout
    private lateinit var libBody: LinearLayout
    private lateinit var search: EditText
    private lateinit var gd: GestureDetector
    private var apps = listOf<App>()
    private var libOpen = false
    private lateinit var host: AppWidgetHost
    private lateinit var awm: AppWidgetManager
    private var pendingWidgetId = -1
    private val REQ_BIND = 41
    private val REQ_CONFIG = 42
    private lateinit var folderLayer: FrameLayout
    private lateinit var folderScrim: View
    private lateinit var folderBox: LinearLayout
    private lateinit var folderTitle: TextView
    private lateinit var folderPanel: ScrollView
    private lateinit var folderGrid: GridLayout
    private var folderOpen = false
    private var folderTile: View? = null
    private var folderLabel: View? = null
    private lateinit var folderBg: MorphBg
    private var folderAnim: ValueAnimator? = null
    private var folderP = 0f
    private var gTile = RectF()
    private var gPanel = RectF()
    private val gTitle = FloatArray(2)
    private val gCells = ArrayList<FloatArray>()
    private val folderCells = ArrayList<View>()
    private var launched = false
    private var editMode = false
    private lateinit var editBar: FrameLayout
    private lateinit var iconProv: IconProvider
    private val jiggles = ArrayList<Animator>()
    private val slotViews = HashMap<Int, View>()
    private var hoverSlot = -1
    private var dragSrcSlot = -1
    private var popAll = true
    private var popKey: String? = null
    private var curFolderId: String? = null
    private var gMini = 0
    private var folderUnder: View? = null
    private var folderBlurBase = 0f
    private var gRadius0 = 0f
    private var gTs0 = 0.43f
    private var widgetGrabR = 0
    private var widgetGrabC = 0
    private val REQ_ICON = 43
    private var pendingIconKey: String? = null
    private lateinit var cropLayer: FrameLayout
    private lateinit var cropView: CropView
    private lateinit var spotLayer: FrameLayout
    private lateinit var spotCol: LinearLayout
    private lateinit var spotInput: EditText
    private lateinit var spotBody: LinearLayout
    private var spotOpen = false
    private lateinit var packLayer: FrameLayout
    private lateinit var packGrid: GridView
    private lateinit var packSearch: EditText
    private var packNames: List<String> = emptyList()
    private var packShown: List<String> = emptyList()
    private var packTarget: String? = null
    private val installTimes = HashMap<String, Long>()
    private val packAdapter = object : BaseAdapter() {
        override fun getCount() = packShown.size
        override fun getItem(p: Int): Any = packShown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val iv = (cv as? ImageView) ?: ImageView(this@MainActivity).apply {
                layoutParams = AbsListView.LayoutParams(dp(76), dp(76)); setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            iv.setImageDrawable(iconProv.packDrawable(packShown[p]))
            return iv
        }
    }
    private var wallKey = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = r.toFloat() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        prefs = Prefs(this)
        Badges.onChange = { refreshBadges() }
        awm = AppWidgetManager.getInstance(this)
        host = AppWidgetHost(this, 1024)
        root = FrameLayout(this)
        wall = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(wall, MATCH, MATCH)
        wallBlur = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY; alpha = 0f
            setColorFilter(Color.argb(90, 0, 0, 0), PorterDuff.Mode.SRC_ATOP)
        }
        root.addView(wallBlur, MATCH, MATCH)

        homeLayer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(40), dp(24), dp(16)) }
        grid = GridLayout(this)
        grid.clipChildren = false
        grid.setOnLongClickListener { homeMenuEmpty(); true }
        homeLayer.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))
        dock = object : FrameLayout(this) {
            override fun onMeasure(ws: Int, hs: Int) {
                dockRow.measure(MeasureSpec.makeMeasureSpec(MeasureSpec.getSize(ws), MeasureSpec.AT_MOST), hs)
                val w = maxOf(dockRow.measuredWidth, dp(80))
                val h = MeasureSpec.getSize(hs)
                setMeasuredDimension(w, h)
                val ew = MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY)
                val eh = MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY)
                dockRow.measure(ew, eh); dockBlur.measure(ew, eh)
            }
        }.apply {
            background = rounded(Color.argb(60, 255, 255, 255), dp(30))
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(30).toFloat()) }
            }
        }
        dockBlur = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            setColorFilter(Color.argb(50, 255, 255, 255), PorterDuff.Mode.SRC_ATOP)
        }
        dockRow = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(12), 0, dp(12), 0); clipChildren = false }
        dock.addView(dockBlur, FrameLayout.LayoutParams(MATCH, MATCH))
        dock.addView(dockRow, FrameLayout.LayoutParams(MATCH, MATCH))
        homeLayer.addView(dock, LinearLayout.LayoutParams(WRAP, dp(100)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        homeLayer.setOnDragListener(dragListener)
        root.addView(homeLayer, MATCH, MATCH)
        editBar = FrameLayout(this).apply { visibility = View.GONE }
        val plus = pill("+").apply { setOnClickListener { pickWidget() } }
        val done = pill("Done").apply { setOnClickListener { exitEdit() } }
        editBar.addView(plus, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.TOP).apply { setMargins(dp(24), dp(6), 0, 0) })
        editBar.addView(done, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.TOP).apply { setMargins(0, dp(6), dp(24), 0) })
        root.addView(editBar, MATCH, WRAP)

        library = FrameLayout(this).apply {
            isClickable = true; visibility = View.GONE
        }
        val lib = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(48), dp(48), dp(48), dp(16)) }
        search = EditText(this).apply {
            hint = "App Library"; setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            setSingleLine(); background = rounded(Color.argb(70, 255, 255, 255), dp(14)); setPadding(dp(16), dp(10), dp(16), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { buildLibrary() }
            })
        }
        libBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lib.addView(search, MATCH, WRAP)
        lib.addView(ScrollView(this).apply { addView(libBody) }, MATCH, MATCH)
        library.addView(lib, MATCH, MATCH)
        root.addView(library, MATCH, MATCH)
        root.addView(buildFolderLayer(), MATCH, MATCH)
        root.addView(buildSpotlight(), MATCH, MATCH)
        root.addView(buildCropLayer(), MATCH, MATCH)
        root.addView(buildPackLayer(), MATCH, MATCH)
        setContentView(root)

        // Swipe LEFT opens the App Library, swipe RIGHT closes it
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (folderOpen || editMode || spotOpen || cropLayer.visibility == View.VISIBLE || packLayer.visibility == View.VISIBLE) return false
                if (vy > 1200 && vy > abs(vx) * 1.8f && !libOpen) { openSpotlight(); return false }
                if (abs(vx) > 800 && abs(vx) > abs(vy) * 1.5f) {
                    if (vx < 0 && !libOpen) setLibrary(true) else if (vx > 0 && libOpen) setLibrary(false)
                }
                return false
            }
        })
    }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean { gd.onTouchEvent(e); return super.dispatchTouchEvent(e) }

    override fun onDestroy() { Badges.onChange = null; super.onDestroy() }

    // Update every red badge in place (no rebuild, so animations/drags aren't disturbed)
    private fun refreshBadges(v: View = root) {
        if (v is CountBadge) { v.update(); return }
        if (v is ViewGroup) for (i in 0 until v.childCount) refreshBadges(v.getChildAt(i))
    }

    override fun onStart() { super.onStart(); try { host.startListening() } catch (e: Exception) { } }
    override fun onStop() { super.onStop(); try { host.stopListening() } catch (e: Exception) { } }

    override fun onResume() {
        super.onResume()
        // undo anything an interrupted animation might have left behind
        homeLayer.animate().cancel()
        if (!libOpen && !spotOpen) { homeLayer.scaleX = 1f; homeLayer.scaleY = 1f; homeLayer.alpha = 1f }
        if (!launched) popAll = true
        launched = false
        reload()
    }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); closeFolder(false); closeSpotlight(); exitEdit(); if (libOpen) setLibrary(false) }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (packLayer.visibility == View.VISIBLE) closePack()
        else if (cropLayer.visibility == View.VISIBLE) hideCrop()
        else if (folderOpen) closeFolder(true)
        else if (spotOpen) closeSpotlight()
        else if (editMode) exitEdit()
        else if (libOpen) setLibrary(false)
    }

    private fun setLibrary(open: Boolean) {
        libOpen = open
        val w = root.width.toFloat()
        val ease = DecelerateInterpolator(2f)
        val ms = 320L
        if (open) {
            library.visibility = View.VISIBLE
            library.translationX = w
            library.animate().translationX(0f).setDuration(ms).setInterpolator(ease).start()
            homeLayer.animate().translationX(-w).alpha(0f).setDuration(ms).setInterpolator(ease).start()
            wallBlur.animate().alpha(1f).setDuration(ms).setInterpolator(ease).start()
        } else {
            closeFolder(false)
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
            search.setText(""); search.clearFocus()
            library.animate().translationX(w).setDuration(ms).setInterpolator(ease)
                .withEndAction { library.visibility = View.GONE }.start()
            homeLayer.animate().translationX(0f).alpha(1f).setDuration(ms).setInterpolator(ease).start()
            wallBlur.animate().alpha(0f).setDuration(ms).setInterpolator(ease).start()
        }
    }

    private fun setupWallpaper() {
        root.requestLayout()
        root.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                root.viewTreeObserver.removeOnGlobalLayoutListener(this)
                applyWallpaper()
            }
        })
    }

    // Fit wallpaper to screen once, blur the strip behind the dock once. Only redone when something changes.
    private fun applyWallpaper() {
        val w = root.width; val h = root.height
        if (w == 0 || h == 0) return
        val f = File(filesDir, "wall.jpg")
        val a = IntArray(2); val r = IntArray(2)
        dock.getLocationOnScreen(a); root.getLocationOnScreen(r)
        val dx = a[0] - r[0]; val dy = a[1] - r[1]
        val key = "${f.lastModified()}|$w|$h|$dx|$dy|${dock.width}|${dock.height}|${prefs.blur}|${prefs.blurStrength}"
        if (key == wallKey) return
        var src: Bitmap? = null
        if (f.exists()) src = BitmapFactory.decodeFile(f.path)
        if (src == null) try { src = WallpaperManager.getInstance(this).drawable?.let { Blur.toBitmap(it) } } catch (e: Exception) { }
        wallKey = key
        if (src == null) {
            wall.setImageDrawable(null); dockBlur.setImageDrawable(null)
            wallBlur.setImageDrawable(null); wallBlur.setBackgroundColor(Color.argb(200, 16, 16, 24))
            return
        }
        val screen = Blur.fitCrop(src, w, h)
        wall.setImageBitmap(screen)
        wallBlur.setBackgroundColor(0)
        wallBlur.setImageBitmap(Blur.blurRegion(screen, 0, 0, w, h, 10, 3))
        if (prefs.blur && dock.width > 0 && dock.height > 0)
            dockBlur.setImageBitmap(Blur.blurRegion(screen, dx, dy, dock.width, dock.height, prefs.blurStrength, 3))
        else dockBlur.setImageDrawable(null)
    }

    private fun reload() {
        iconProv = IconProvider(this, prefs)
        val icons = iconProv
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(q, 0).map { ri ->
            val cn = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
            val orig = ri.loadLabel(pm).toString()
            App(cn, prefs.label(Prefs.key(cn), orig), orig, icons.icon(cn, ri.loadIcon(pm), dp(prefs.iconDp)), ri.activityInfo.applicationInfo.category)
        }.sortedBy { it.label.lowercase() }
        if (!prefs.sp.contains("home")) {
            prefs.dock = apps.take(5).map { it.key }
            prefs.home = apps.drop(5).take(prefs.cols * prefs.rows).map { it.key }
        }
        buildHome(); buildLibrary()
    }

    private fun dr(a: App): Drawable = a.icon.constantState?.newDrawable() ?: a.icon

    private fun cell(a: App, label: Boolean, click: (View) -> Unit, long: (View) -> Unit,
                     draggable: Boolean = false, badge: (() -> Unit)? = null): LinearLayout =
        cellOf(ImageView(this).apply { setImageDrawable(dr(a)) }, if (label) a.label else null, click, long, draggable, badge, listOf(a.cn.packageName))

    // Generic icon cell: [icon frame (+ delete badge in edit mode)] + optional label
    private fun cellOf(content: View, caption: String?, click: (View) -> Unit, long: (View) -> Unit,
                       draggable: Boolean = false, badge: (() -> Unit)? = null,
                       badgePkgs: List<String> = emptyList()): LinearLayout {
        val ic = dp(prefs.iconDp)
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        return LinearLayout(this).apply {
            val self = this
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(4), dp(4), dp(4))
            clipChildren = false
            val frame = FrameLayout(context).apply { clipChildren = false }
            frame.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))
            if (badge != null) {
                val bv = TextView(context).apply {
                    this.text = "\u2212"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(235, 60, 60, 67)) }
                    setOnClickListener {
                        self.animate().scaleX(0f).scaleY(0f).alpha(0f).setDuration(160).withEndAction { badge() }.start()
                    }
                }
                frame.addView(bv, FrameLayout.LayoutParams(dp(24), dp(24)).apply { leftMargin = -dp(8); topMargin = -dp(8) })
            }
            if (badgePkgs.isNotEmpty()) {
                frame.addView(CountBadge(context, badgePkgs),
                    FrameLayout.LayoutParams(WRAP, dp(20), Gravity.TOP or Gravity.END).apply { rightMargin = -dp(6); topMargin = -dp(6) })
            }
            addView(frame, LinearLayout.LayoutParams(ic, ic))
            if (caption != null) addView(TextView(context).apply {
                this.text = caption; setTextColor(Color.WHITE); textSize = 12f; maxLines = 1
                ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER; setShadowLayer(4f, 0f, 1f, Color.BLACK)
            })
            setOnClickListener { click(self) }
            var x0 = 0f; var y0 = 0f; var moved = false
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        x0 = e.rawX; y0 = e.rawY; moved = false
                        v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(120).setInterpolator(DecelerateInterpolator()).start()
                    }
                    MotionEvent.ACTION_MOVE -> if (draggable && editMode && !moved &&
                        (abs(e.rawX - x0) > slop || abs(e.rawY - y0) > slop)) {
                        moved = true
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                        long(v)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(300)
                        .setInterpolator(OvershootInterpolator(2.5f)).start()
                }
                false
            }
            setOnLongClickListener { long(self); true }
        }
    }

    // 3x3 mini-icon folder tile for the home screen (same frosted look as the library folders)
    private fun folderTileView(list: List<App>): GridLayout {
        val s = dp(prefs.iconDp)
        val pad = (s * 0.1f).toInt(); val mg = dp(1)
        val m = (s - 2 * pad) / 3 - 2 * mg
        val g = GridLayout(this).apply {
            columnCount = 3; setPadding(pad, pad, pad, pad)
            background = rounded(Color.argb(70, 255, 255, 255), folderRadius())
        }
        list.take(9).forEachIndexed { i, a ->
            g.addView(ImageView(this).apply { setImageDrawable(dr(a)) },
                GridLayout.LayoutParams(GridLayout.spec(i / 3), GridLayout.spec(i % 3)).apply { width = m; height = m; setMargins(mg, mg, mg, mg) })
        }
        return g
    }

    private fun folderRadius() = (dp(prefs.iconDp) * 0.17f).toInt()

    private fun iconRadius() = (dp(prefs.iconDp) * iconProv.ratio()).toInt()

    private fun isFolder(k: String) = k.startsWith("F:")

    private fun folderAppList(id: String) = prefs.folderApps(id).mapNotNull { k -> apps.find { it.key == k } }

    private fun homeFolderCell(id: String): View? {
        val list = folderAppList(id)
        if (list.isEmpty()) return null
        val tile = folderTileView(list)
        return cellOf(tile, prefs.folderName(id),
            { v -> openFolderPanel(prefs.folderName(id), folderAppList(id), tile, (v as ViewGroup).getChildAt(1), folderRadius().toFloat(), id) },
            { v -> startDrag(v, id) }, true,
            if (editMode) ({ removeFolder(id) }) else null,
            folderAppList(id).map { it.cn.packageName }.distinct())
    }

    // ---- pop-in ----
    private fun pop(v: View, delay: Long = 0L) {
        v.scaleX = 0.5f; v.scaleY = 0.5f; v.alpha = 0f
        v.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(delay).setDuration(420)
            .setInterpolator(OvershootInterpolator(1.6f)).start()
    }

    // ---- jiggle edit mode ----
    private fun stopJiggle() { jiggles.forEach { it.cancel() }; jiggles.clear() }

    private fun jiggle(v: View, amp: Float = 2.2f) {
        val d = if (Random.nextBoolean()) 1f else -1f
        val a = ObjectAnimator.ofFloat(v, View.ROTATION, -amp * d, amp * d)
        a.duration = (105 + Random.nextInt(40)).toLong()
        a.repeatMode = ValueAnimator.REVERSE; a.repeatCount = ValueAnimator.INFINITE
        a.startDelay = Random.nextInt(90).toLong()
        a.start(); jiggles.add(a)
    }

    private fun pill(t: String) = TextView(this).apply {
        this.text = t; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
        setPadding(dp(18), dp(6), dp(18), dp(6)); background = rounded(Color.argb(90, 255, 255, 255), dp(16))
    }

    private fun enterEdit() {
        if (editMode) return
        editMode = true
        editBar.visibility = View.VISIBLE; editBar.alpha = 0f; editBar.translationY = -dp(16).toFloat()
        editBar.animate().alpha(1f).translationY(0f).setDuration(300).setInterpolator(PathInterpolator(0.22f, 1f, 0.36f, 1f)).start()
        buildHome()
    }

    private fun exitEdit() {
        if (!editMode) return
        editMode = false
        editBar.animate().alpha(0f).translationY(-dp(16).toFloat()).setDuration(220).withEndAction { editBar.visibility = View.GONE }.start()
        buildHome()
    }

    private fun launch(a: App, from: View? = null) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(a.cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val opts = if (from != null && from.width > 0)
            ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height).toBundle() else null
        launched = true
        prefs.pushRecent(a.key)
        startActivity(i, opts)
    }

    private var dragKey: String? = null
    private var pendingKey: String? = null

    private fun slots(): MutableList<String> {
        val l = prefs.home.toMutableList()
        while (l.size < prefs.cols * prefs.rows) l.add("")
        return l
    }

    private fun removeFromHome(key: String) { prefs.home = prefs.home.map { if (it == key) "" else it } }

    private fun addToHome(key: String) {
        val sl = slots()
        if (key in sl) return
        val cov = coveredSlots()
        val e = sl.indices.firstOrNull { sl[it].isEmpty() && it !in cov } ?: -1
        if (e < 0) { Toast.makeText(this, "Home screen is full", Toast.LENGTH_SHORT).show(); return }
        sl[e] = key; prefs.home = sl
    }

    // Long-press (or, in edit mode, just dragging) picks the item up. Drop it back in place for its menu.
    private fun startDrag(v: View, key: String) {
        dragKey = key
        dragSrcSlot = prefs.home.indexOf(key)
        v.alpha = 0.3f
        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        v.startDragAndDrop(ClipData.newPlainText("app", key), View.DragShadowBuilder(v), null, 0)
    }

    private val dragListener = View.OnDragListener { _, e ->
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED -> dragKey != null
            DragEvent.ACTION_DRAG_LOCATION -> { updateHover(e.x, e.y); true }
            DragEvent.ACTION_DROP -> { clearHover(); handleDrop(e.x, e.y); true }
            DragEvent.ACTION_DRAG_ENDED -> {
                clearHover(); dragKey = null
                buildHome()
                pendingKey?.let { k ->
                    pendingKey = null
                    if (isFolder(k)) folderMenu(k) else apps.find { it.key == k }?.let { homeMenu(it) }
                }
                true
            }
            else -> true
        }
    }

    // Which grid cell is under the finger, and is it the middle (merge-into-folder) zone?
    private fun locate(x: Float, y: Float): Pair<Int, Boolean>? {
        if (y < grid.top || y >= grid.bottom || y >= dock.top - dp(16)) return null
        val cols = prefs.cols; val rows = prefs.rows
        val fx = (x - grid.left) / (grid.width / cols.toFloat())
        val fy = (y - grid.top) / (grid.height / rows.toFloat())
        val col = fx.toInt().coerceIn(0, cols - 1); val row = fy.toInt().coerceIn(0, rows - 1)
        val central = abs(fx - col - 0.5f) < 0.3f && abs(fy - row - 0.5f) < 0.3f
        return (row * cols + col) to central
    }

    private fun updateHover(x: Float, y: Float) {
        val key = dragKey ?: return
        var target = -1
        if (!isFolder(key) && !key.startsWith("W:")) locate(x, y)?.let { (t, central) ->
            if (central && t != dragSrcSlot && slotViews.containsKey(t)) target = t
        }
        if (target == hoverSlot) return
        slotViews[hoverSlot]?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(150)?.start()
        slotViews[target]?.animate()?.scaleX(1.18f)?.scaleY(1.18f)?.setDuration(200)?.setInterpolator(OvershootInterpolator())?.start()
        hoverSlot = target
    }

    private fun clearHover() {
        slotViews[hoverSlot]?.animate()?.scaleX(1f)?.scaleY(1f)?.setDuration(150)?.start()
        hoverSlot = -1
    }

    private fun handleDrop(x: Float, y: Float) {
        val key = dragKey ?: return
        if (key.startsWith("W:")) { handleWidgetDrop(key.substring(2).toInt(), x, y); return }
        val dragIsFolder = isFolder(key)
        if (!dragIsFolder && apps.none { it.key == key }) return
        val present = apps.map { it.key }.toSet()
        val sl = slots()
        val oldSlot = sl.indexOf(key)
        val dockList = prefs.dock.filter { it in present }.toMutableList()
        val oldDock = dockList.indexOf(key)

        if (y >= dock.top - dp(16)) {
            if (dragIsFolder) { Toast.makeText(this, "Folders can't go in the dock", Toast.LENGTH_SHORT).show(); return }
            var idx = 0
            for (i in 0 until dockRow.childCount) {
                val c = dockRow.getChildAt(i)
                val l = dock.left + c.left; val r = dock.left + c.right
                if (i == oldDock && x >= l && x <= r) { pendingKey = key; return }
                if (i != oldDock && (l + r) / 2f < x) idx++
            }
            dockList.remove(key)
            if (dockList.size >= 8) { Toast.makeText(this, "Dock is full", Toast.LENGTH_SHORT).show(); return }
            dockList.add(idx.coerceAtMost(dockList.size), key)
            prefs.dock = dockList
            if (oldSlot >= 0) { sl[oldSlot] = ""; prefs.home = sl }
            popKey = key
            return
        }

        val (t, central) = locate(x, y) ?: return
        if (t in coveredSlots()) return
        if (t == oldSlot) { pendingKey = key; return }
        val other = sl[t]
        fun removeSource() {
            if (oldSlot >= 0) sl[oldSlot] = ""
            if (oldDock >= 0) { dockList.remove(key); prefs.dock = dockList }
        }
        // app dropped on a folder -> goes inside it
        if (!dragIsFolder && isFolder(other) && (central || oldDock >= 0)) {
            prefs.setFolderApps(other, (prefs.folderApps(other) + key).distinct())
            removeSource(); prefs.home = sl; popKey = other
            return
        }
        // app dropped on the middle of another app -> new folder
        if (!dragIsFolder && other.isNotEmpty() && !isFolder(other) && central) {
            val oa = apps.find { it.key == other }
            if (oa != null) {
                val id = prefs.newFolder(catName(oa), listOf(other, key))
                removeSource(); sl[t] = id; prefs.home = sl; popKey = id
                return
            }
        }
        // otherwise move, or swap places
        if (oldDock >= 0 && isFolder(other)) return
        sl[t] = key
        if (oldSlot >= 0) sl[oldSlot] = other
        if (oldDock >= 0) {
            dockList.remove(key)
            if (other.isNotEmpty()) dockList.add(oldDock.coerceAtMost(dockList.size), other)
            prefs.dock = dockList
        }
        prefs.home = sl
        popKey = key
    }

    // ---------------- Pick a specific icon from the icon pack ----------------
    private fun buildPackLayer(): View {
        packLayer = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(Color.argb(238, 14, 14, 20)); isClickable = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(32), dp(24), dp(32), dp(16)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        packSearch = EditText(this).apply {
            hint = "Search icons"; setHintTextColor(Color.argb(170, 255, 255, 255)); setTextColor(Color.WHITE); textSize = 17f
            setSingleLine(); background = rounded(Color.argb(70, 255, 255, 255), dp(12)); setPadding(dp(16), dp(10), dp(16), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { filterPack() }
            })
        }
        val cancel = pill("Cancel").apply { setOnClickListener { closePack() } }
        top.addView(packSearch, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(cancel, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(12) })
        packGrid = GridView(this).apply {
            numColumns = GridView.AUTO_FIT; columnWidth = dp(76); stretchMode = GridView.STRETCH_COLUMN_WIDTH
            adapter = packAdapter
            setOnItemClickListener { _, _, pos, _ -> choosePackIcon(packShown[pos]) }
        }
        col.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(packGrid, LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = dp(12) })
        packLayer.addView(col, MATCH, MATCH)
        return packLayer
    }

    private fun filterPack() {
        val q = packSearch.text.toString().trim().lowercase()
        packShown = if (q.isEmpty()) packNames else packNames.filter { it.lowercase().contains(q) }
        packAdapter.notifyDataSetChanged()
    }

    private fun openPackPicker(a: App) {
        if (!iconProv.hasPack()) { Toast.makeText(this, "Choose an icon pack in Settings first", Toast.LENGTH_SHORT).show(); return }
        packTarget = a.key
        packNames = iconProv.allDrawables()
        packSearch.setText("")
        packShown = packNames
        packAdapter.notifyDataSetChanged()
        packGrid.setSelection(0)
        packLayer.alpha = 0f; packLayer.visibility = View.VISIBLE
        packLayer.animate().alpha(1f).setDuration(250).start()
    }

    private fun closePack() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(packSearch.windowToken, 0)
        packLayer.animate().alpha(0f).setDuration(200).withEndAction { packLayer.visibility = View.GONE }.start()
    }

    private fun choosePackIcon(name: String) {
        packTarget?.let { prefs.sp.edit().putString("pi_$it", name).apply() }
        closePack()
        reload()
    }

    private fun recentMenu(a: App) = menu(a, listOf(
        "Keep in Dock" to {
            if (a.key !in prefs.dock) {
                if (prefs.dock.size >= 8) Toast.makeText(this, "Dock is full", Toast.LENGTH_SHORT).show()
                else prefs.dock = prefs.dock + a.key
            }
            buildHome()
        },
        "Remove from Recents" to { prefs.removeRecent(a.key); buildHome() }))

    private fun widgetOverlaps(id: Int, r0: Int, c0: Int, r1: Int, c1: Int): Boolean =
        widgets().any { o -> o.id != id && r0 < o.r + o.rs && o.r < r1 && c0 < o.c + o.cs && o.c < c1 }

    private fun installTime(pkg: String): Long = installTimes.getOrPut(pkg) {
        try { packageManager.getPackageInfo(pkg, 0).firstInstallTime } catch (e: Exception) { 0L }
    }

    // ---------------- Widget move / remove ----------------
    private fun badgeOf(target: View, action: () -> Unit): TextView = TextView(this).apply {
        this.text = "\u2212"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(235, 60, 60, 67)) }
        setOnClickListener { target.animate().scaleX(0f).scaleY(0f).alpha(0f).setDuration(160).withEndAction { action() }.start() }
    }

    private fun removeWidget(id: Int) {
        host.deleteAppWidgetId(id)
        saveWidgets(widgets().filter { it.id != id })
        buildHome()
    }

    private fun handleWidgetDrop(id: Int, x: Float, y: Float) {
        val w = widgets().find { it.id == id } ?: return
        val (t, _) = locate(x, y) ?: return
        val cols = prefs.cols; val rows = prefs.rows
        val r = (t / cols - widgetGrabR).coerceIn(0, maxOf(0, rows - w.rs))
        val c = (t % cols - widgetGrabC).coerceIn(0, maxOf(0, cols - w.cs))
        for (o in widgets()) if (o.id != id && r < o.r + o.rs && o.r < r + w.rs && c < o.c + o.cs && o.c < c + w.cs) return
        placeWidget(id, w.rs, w.cs, r, c)
    }

    // ---------------- Custom icons (pick from gallery + crop) ----------------
    private fun iconItems(a: App): List<Pair<String, () -> Unit>> {
        val l = mutableListOf<Pair<String, () -> Unit>>("Change Icon" to { pickIcon(a) })
        if (prefs.pack.isNotEmpty()) l.add("Pick From Icon Pack" to { openPackPicker(a) })
        if (customIconFile(this, a.key).exists() || prefs.sp.contains("pi_" + a.key))
            l.add("Reset Icon" to {
                customIconFile(this, a.key).delete()
                prefs.sp.edit().remove("pi_" + a.key).apply()
                reload()
            })
        return l
    }

    private fun pickIcon(a: App) {
        pendingIconKey = a.key
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), REQ_ICON)
    }

    private fun loadForCrop(uri: Uri) {
        try {
            val bmp = Blur.decodeUpright(this, uri, 2048) ?: throw Exception("decode failed")
            cropView.setBitmap(bmp)
            cropLayer.alpha = 0f; cropLayer.visibility = View.VISIBLE
            cropLayer.animate().alpha(1f).setDuration(250).start()
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't load that image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildCropLayer(): View {
        cropLayer = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(Color.BLACK); isClickable = true }
        cropView = CropView(this)
        cropLayer.addView(cropView, MATCH, MATCH)
        cropLayer.addView(TextView(this).apply {
            text = "Move and Scale"; setTextColor(Color.WHITE); textSize = 17f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        }, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP).apply { topMargin = dp(24) })
        val cancel = pill("Cancel").apply { setOnClickListener { hideCrop() } }
        val choose = pill("Choose").apply { setOnClickListener { saveCrop() } }
        cropLayer.addView(cancel, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(32), 0, 0, dp(32)) })
        cropLayer.addView(choose, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(32), dp(32)) })
        return cropLayer
    }

    private fun hideCrop() {
        cropLayer.animate().alpha(0f).setDuration(200).withEndAction { cropLayer.visibility = View.GONE }.start()
    }

    private fun saveCrop() {
        val bmp = cropView.result(256)
        val key = pendingIconKey
        if (bmp != null && key != null) {
            val f = customIconFile(this, key)
            f.parentFile?.mkdirs()
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }
        pendingIconKey = null
        hideCrop()
        reload()
    }

    // ---------------- Spotlight search (swipe down on the home screen) ----------------
    private fun buildSpotlight(): View {
        spotLayer = FrameLayout(this).apply { visibility = View.GONE; isClickable = true }
        spotCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(32), dp(24), dp(32), dp(16)) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        spotInput = EditText(this).apply {
            hint = "Search"; setHintTextColor(Color.argb(170, 255, 255, 255)); setTextColor(Color.WHITE); textSize = 17f
            setSingleLine(); imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = rounded(Color.argb(70, 255, 255, 255), dp(12)); setPadding(dp(16), dp(10), dp(16), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { buildSpotlightResults() }
            })
            setOnEditorActionListener { _, _, _ ->
                val q = text.toString().trim().lowercase()
                if (q.isNotEmpty()) {
                    val hit = apps.firstOrNull { it.label.lowercase().startsWith(q) } ?: apps.firstOrNull { it.label.lowercase().contains(q) }
                    if (hit != null) { closeSpotlight(); launch(hit) } else webSearch(q)
                }
                true
            }
        }
        val cancel = TextView(this).apply {
            text = "Cancel"; setTextColor(Color.WHITE); textSize = 17f; setPadding(dp(16), dp(8), dp(2), dp(8))
            setOnClickListener { closeSpotlight() }
        }
        bar.addView(spotInput, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(cancel, LinearLayout.LayoutParams(WRAP, WRAP))
        spotBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        spotCol.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        spotCol.addView(ScrollView(this).apply { addView(spotBody) }, LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = dp(8) })
        spotLayer.addView(spotCol, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER_HORIZONTAL))
        return spotLayer
    }

    private fun spotHeader(t: String) = TextView(this).apply {
        this.text = t; setTextColor(Color.argb(190, 255, 255, 255)); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(6), dp(18), 0, dp(6))
    }

    private fun spotRow(a: App?, label: String, onClick: () -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), dp(10), dp(14), dp(10))
        if (a != null) addView(ImageView(context).apply { setImageDrawable(dr(a)) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        else addView(View(context), LinearLayout.LayoutParams(dp(40), dp(40)))
        addView(TextView(context).apply {
            this.text = label; setTextColor(Color.WHITE); textSize = 17f; maxLines = 1
            ellipsize = TextUtils.TruncateAt.END; setPadding(dp(14), 0, 0, 0)
        })
        setOnClickListener { onClick() }
    }

    private fun spotCard(rows: List<View>): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; clipToOutline = true
            background = rounded(Color.argb(60, 255, 255, 255), dp(14))
        }
        rows.forEachIndexed { i, r ->
            if (i > 0) card.addView(View(this).apply { setBackgroundColor(Color.argb(40, 255, 255, 255)) },
                LinearLayout.LayoutParams(MATCH, 1).apply { leftMargin = dp(68) })
            card.addView(r)
        }
        return card
    }

    private fun webSearch(q: String) {
        try { startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)) }
        catch (e: Exception) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))) }
            catch (e2: Exception) { }
        }
    }

    private fun buildSpotlightResults() {
        spotBody.removeAllViews()
        val q = spotInput.text.toString().trim().lowercase()
        if (q.isEmpty()) {
            val rec = prefs.recents().mapNotNull { k -> apps.find { it.key == k } }
            if (rec.isNotEmpty()) {
                spotBody.addView(spotHeader("Recent"))
                spotBody.addView(spotCard(rec.map { a -> spotRow(a, a.label) { closeSpotlight(); launch(a) } }))
            }
            return
        }
        val hits = apps.filter { it.label.lowercase().contains(q) }
            .sortedBy { if (it.label.lowercase().startsWith(q)) 0 else 1 }.take(12)
        if (hits.isNotEmpty()) {
            spotBody.addView(spotHeader("Applications"))
            spotBody.addView(spotCard(hits.map { a -> spotRow(a, a.label) { closeSpotlight(); launch(a) } }))
        }
        spotBody.addView(spotHeader("Search the web"))
        spotBody.addView(spotCard(listOf(spotRow(null, "Search web for \u201C" + spotInput.text.toString().trim() + "\u201D") { webSearch(q) })))
    }

    private fun openSpotlight() {
        if (spotOpen) return
        spotOpen = true
        spotInput.setText("")
        buildSpotlightResults()
        val colLp = spotCol.layoutParams as FrameLayout.LayoutParams
        colLp.width = minOf(dp(620), root.width)
        spotCol.requestLayout()
        val ease = PathInterpolator(0.22f, 1f, 0.36f, 1f)
        spotLayer.visibility = View.VISIBLE; spotLayer.alpha = 0f; spotLayer.translationY = -dp(24).toFloat()
        spotLayer.animate().alpha(1f).translationY(0f).setDuration(320).setInterpolator(ease).start()
        homeLayer.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration(320).setInterpolator(ease).start()
        wallBlur.animate().alpha(1f).setDuration(320).setInterpolator(ease).start()
        spotInput.requestFocus()
        spotInput.postDelayed({
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(spotInput, InputMethodManager.SHOW_IMPLICIT)
        }, 180)
    }

    private fun closeSpotlight() {
        if (!spotOpen) return
        spotOpen = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(spotInput.windowToken, 0)
        spotInput.clearFocus()
        val ease = PathInterpolator(0.22f, 1f, 0.36f, 1f)
        spotLayer.animate().alpha(0f).translationY(-dp(24).toFloat()).setDuration(240).setInterpolator(ease)
            .withEndAction { spotLayer.visibility = View.GONE }.start()
        homeLayer.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(ease).start()
        wallBlur.animate().alpha(0f).setDuration(240).setInterpolator(ease).start()
    }

    // ---------------- Widgets ----------------
    private fun widgets(): MutableList<W> =
        prefs.sp.getString("widgets", "")!!.split(";").filter { it.isNotEmpty() }.mapNotNull {
            val p = it.split(",")
            if (p.size == 5) W(p[0].toInt(), p[1].toInt(), p[2].toInt(), p[3].toInt(), p[4].toInt()) else null
        }.toMutableList()

    private fun saveWidgets(l: List<W>) {
        prefs.sp.edit().putString("widgets", l.joinToString(";") { "${it.id},${it.r},${it.c},${it.rs},${it.cs}" }).apply()
    }

    private fun coveredSlots(): Set<Int> {
        val s = HashSet<Int>(); val cols = prefs.cols; val rows = prefs.rows
        for (w in widgets()) for (r in w.r until minOf(rows, w.r + w.rs)) for (c in w.c until minOf(cols, w.c + w.cs)) s.add(r * cols + c)
        return s
    }

    private fun homeMenuEmpty() {
        Ios.sheet(this, null, listOf(
            Ios.Item("Add Widget") { pickWidget() },
            Ios.Item("Edit Home Screen") { enterEdit() },
            Ios.Item("Launcher Settings") { startActivity(Intent(this, SettingsActivity::class.java)) }))
    }

    private fun widgetMenu(w: W) {
        Ios.sheet(this, null, listOf(
            Ios.Item("Resize") { resizeWidget(w) },
            Ios.Item("Remove Widget", true) {
                host.deleteAppWidgetId(w.id)
                saveWidgets(widgets().filter { it.id != w.id }); buildHome()
            }))
    }

    private fun resizeWidget(w: W) {
        Ios.sheet(this, "Width (columns)", (1..prefs.cols).map { c ->
            Ios.Item(c.toString()) {
                Ios.sheet(this, "Height (rows)", (1..prefs.rows).map { r ->
                    Ios.Item(r.toString()) { placeWidget(w.id, r, c, w.r, w.c); buildHome() }
                })
            }
        })
    }

    private fun pickWidget() {
        val pm = packageManager
        val list = awm.installedProviders.sortedBy { it.loadLabel(pm).lowercase() }
        Ios.sheet(this, "Add Widget", list.map { info ->
            Ios.Item(info.loadLabel(pm) + "  \u2022  " + info.provider.packageName.substringAfterLast('.')) { startBind(info) }
        })
    }

    private fun startBind(info: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pendingWidgetId = id
        try {
            if (awm.bindAppWidgetIdIfAllowed(id, info.provider)) afterBind(id)
            else startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider), REQ_BIND)
        } catch (e: Exception) { cancelWidget() }
    }

    private fun afterBind(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info?.configure != null) {
            try { host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null) }
            catch (e: Exception) { finishWidget(id) }
        } else finishWidget(id)
    }

    private fun finishWidget(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info == null) { cancelWidget(); return }
        val cols = prefs.cols; val rows = prefs.rows
        var rs: Int; var cs: Int
        if (Build.VERSION.SDK_INT >= 31 && info.targetCellWidth > 0 && info.targetCellHeight > 0) {
            rs = info.targetCellHeight; cs = info.targetCellWidth
        } else {
            val cw = grid.width / cols.toFloat(); val ch = grid.height / rows.toFloat()
            cs = ceil(info.minWidth / cw.toDouble()).toInt(); rs = ceil(info.minHeight / ch.toDouble()).toInt()
        }
        pendingWidgetId = -1
        placeWidget(id, rs, cs); buildHome()
    }

    private fun cancelWidget() {
        if (pendingWidgetId != -1) host.deleteAppWidgetId(pendingWidgetId)
        pendingWidgetId = -1
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val id = pendingWidgetId
        if (req == REQ_BIND) { if (res == RESULT_OK && id != -1) afterBind(id) else cancelWidget() }
        else if (req == REQ_CONFIG) { if (res == RESULT_OK && id != -1) finishWidget(id) else cancelWidget() }
        else if (req == REQ_ICON && res == RESULT_OK) { data?.data?.let { loadForCrop(it) } }
    }

    // Find room for a widget (first free spot, pushing apps out of its way), then save it
    private fun placeWidget(id: Int, rs0: Int, cs0: Int, pr: Int = -1, pc: Int = -1) {
        val cols = prefs.cols; val rows = prefs.rows
        val rs = rs0.coerceIn(1, rows); val cs = cs0.coerceIn(1, cols)
        val others = widgets().filter { it.id != id }
        val taken = HashSet<Int>()
        for (w in others) for (r in w.r until minOf(rows, w.r + w.rs)) for (c in w.c until minOf(cols, w.c + w.cs)) taken.add(r * cols + c)
        val sl = slots()
        fun fits(r: Int, c: Int, needEmpty: Boolean): Boolean {
            if (r + rs > rows || c + cs > cols) return false
            for (rr in r until r + rs) for (cc in c until c + cs) {
                val i = rr * cols + cc
                if (i in taken) return false
                if (needEmpty && sl[i].isNotEmpty()) return false
            }
            return true
        }
        var pos: Pair<Int, Int>? = null
        if (pr >= 0 && fits(pr, pc, false)) pos = pr to pc
        if (pos == null) search@ for (need in listOf(true, false)) for (r in 0 until rows) for (c in 0 until cols)
            if (fits(r, c, need)) { pos = r to c; break@search }
        if (pos == null) {
            Toast.makeText(this, "No room for that widget", Toast.LENGTH_SHORT).show()
            if (widgets().none { it.id == id }) host.deleteAppWidgetId(id)
            return
        }
        val rect = HashSet<Int>()
        for (rr in pos.first until pos.first + rs) for (cc in pos.second until pos.second + cs) rect.add(rr * cols + cc)
        for (i in rect) if (sl[i].isNotEmpty()) {
            val j = sl.indices.firstOrNull { sl[it].isEmpty() && it !in rect && it !in taken }
            if (j != null) { sl[j] = sl[i]; sl[i] = "" }
        }
        saveWidgets(others + W(id, pos.first, pos.second, rs, cs))
        prefs.home = sl
    }

    private fun buildHome() {
        closeFolder(false)
        stopJiggle()
        val cols = prefs.cols; val rows = prefs.rows
        grid.removeAllViews(); grid.columnCount = cols; grid.rowCount = rows
        slotViews.clear()
        val by = apps.associateBy { it.key }
        val covered = coveredSlots()
        var n = 0
        prefs.home.take(cols * rows).forEachIndexed { i, key ->
            if (i in covered || key.isEmpty()) return@forEachIndexed
            val v: View = if (isFolder(key)) (homeFolderCell(key) ?: return@forEachIndexed) else {
                val a = by[key] ?: return@forEachIndexed
                cell(a, true, { vv -> if (!editMode) launch(a, vv) }, { vv -> startDrag(vv, a.key) }, true,
                    if (editMode) ({ removeFromHome(a.key); buildHome() }) else null)
            }
            val lp = GridLayout.LayoutParams(GridLayout.spec(i / cols, 1f), GridLayout.spec(i % cols, 1f)).apply { width = 0; height = 0 }
            slotViews[i] = v
            grid.addView(v, lp)
            if (editMode) jiggle(v)
            if (popAll) pop(v, (n * 16L).coerceAtMost(450L)) else if (key == popKey) pop(v)
            n++
        }
        // GridLayout drops rows/columns that have no views, which made the grid "shrink" after
        // deleting apps. An invisible Space in every free cell keeps all rows and columns alive.
        for (i in 0 until cols * rows) if (slotViews[i] == null) {
            grid.addView(Space(this), GridLayout.LayoutParams(GridLayout.spec(i / cols, 1f), GridLayout.spec(i % cols, 1f)).apply { width = 0; height = 0 })
        }
        for (w in widgets()) {
            if (w.r >= rows || w.c >= cols) continue
            val info = awm.getAppWidgetInfo(w.id) ?: continue
            val hv = host.createView(this, w.id, info)
            hv.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
                val d = resources.displayMetrics.density
                val wd = ((r - l) / d).toInt(); val hd = ((b - t) / d).toInt()
                if (hv.tag != "$wd,$hd") { hv.tag = "$wd,$hd"; hv.updateAppWidgetSize(null, wd, hd, wd, hd) }
            }
            val wrap = WidgetWrap(this)
            wrap.addView(hv, FrameLayout.LayoutParams(MATCH, MATCH))
            if (editMode) {
                val ov = WidgetEditOverlay(this)
                var cur = intArrayOf(w.r, w.c, w.rs, w.cs)
                ov.onMove = { lx, ly ->
                    widgetGrabC = (lx / (grid.width / cols.toFloat())).toInt().coerceIn(0, maxOf(0, w.cs - 1))
                    widgetGrabR = (ly / (grid.height / rows.toFloat())).toInt().coerceIn(0, maxOf(0, w.rs - 1))
                    startDrag(wrap, "W:" + w.id)
                }
                ov.onResizeStart = { cur = intArrayOf(w.r, w.c, w.rs, w.cs) }
                ov.onResizeDrag = { hdl, rx, ry ->
                    val loc = IntArray(2); grid.getLocationOnScreen(loc)
                    val cw = grid.width / cols.toFloat(); val ch = grid.height / rows.toFloat()
                    val gx = rx - loc[0]; val gy = ry - loc[1]
                    var r0 = w.r; var c0 = w.c
                    val r1o = w.r + w.rs; val c1o = w.c + w.cs
                    var r1 = r1o; var c1 = c1o
                    when (hdl) {
                        0 -> c0 = Math.round(gx / cw).coerceIn(0, c1o - 1)
                        1 -> r0 = Math.round(gy / ch).coerceIn(0, r1o - 1)
                        2 -> c1 = Math.round(gx / cw).coerceIn(c0 + 1, cols)
                        else -> r1 = Math.round(gy / ch).coerceIn(r0 + 1, rows)
                    }
                    if (!widgetOverlaps(w.id, r0, c0, r1, c1)) {
                        cur = intArrayOf(r0, c0, r1 - r0, c1 - c0)
                        val lp2 = wrap.layoutParams as GridLayout.LayoutParams
                        lp2.rowSpec = GridLayout.spec(r0, r1 - r0, 1f)
                        lp2.columnSpec = GridLayout.spec(c0, c1 - c0, 1f)
                        wrap.layoutParams = lp2
                    }
                }
                ov.onResizeEnd = { placeWidget(w.id, cur[2], cur[3], cur[0], cur[1]); buildHome() }
                wrap.addView(ov, FrameLayout.LayoutParams(MATCH, MATCH))
                wrap.addView(badgeOf(wrap) { removeWidget(w.id) },
                    FrameLayout.LayoutParams(dp(24), dp(24)).apply { leftMargin = -dp(8); topMargin = -dp(8) })
                jiggle(wrap, 0.6f)
            } else {
                wrap.onLongPress = { wrap.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); widgetMenu(w) }
            }
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(w.r, minOf(w.rs, rows - w.r), 1f), GridLayout.spec(w.c, minOf(w.cs, cols - w.c), 1f)
            ).apply { width = 0; height = 0; setMargins(dp(6), dp(6), dp(6), dp(6)) }
            grid.addView(wrap, lp)
            if (popAll) pop(wrap, 100L)
        }
        dock.layoutParams = (dock.layoutParams as LinearLayout.LayoutParams).apply {
            width = WRAP; height = dp(prefs.iconDp + 36); topMargin = dp(8)
        }
        dockRow.removeAllViews()
        prefs.dock.mapNotNull { by[it] }.forEachIndexed { i, a ->
            val v = cell(a, false, { vv -> if (!editMode) launch(a, vv) }, { vv -> startDrag(vv, a.key) }, true,
                if (editMode) ({ prefs.dock = prefs.dock - a.key; buildHome() }) else null)
            dockRow.addView(v, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(8), 0, dp(8), 0) })
            if (editMode) jiggle(v)
            if (popAll) pop(v, 200L + i * 40L) else if (a.key == popKey) pop(v)
        }
        // iPadOS-style: recently used apps appear on the right side of the dock, after a divider
        if (prefs.dockRecents && !editMode) {
            val pinned = prefs.dock.toSet()
            val rec = prefs.recents().filter { it !in pinned }.mapNotNull { by[it] }.take(3)
            if (rec.isNotEmpty()) {
                dockRow.addView(View(this).apply { setBackgroundColor(Color.argb(110, 255, 255, 255)) },
                    LinearLayout.LayoutParams(dp(1), (dp(prefs.iconDp) * 0.8f).toInt()).apply { setMargins(dp(8), 0, dp(8), 0) })
                rec.forEachIndexed { i, a ->
                    val v = cell(a, false, { vv -> launch(a, vv) }, { recentMenu(a) })
                    dockRow.addView(v, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(8), 0, dp(8), 0) })
                    if (popAll) pop(v, 300L + i * 40L)
                }
            }
        }
        popAll = false; popKey = null
        setupWallpaper()
    }

    private val catOrder = listOf("Utilities", "Settings", "Media", "Video", "Communication", "Games")

    // Android's own app categories are unreliable, so we also match on package name / label.
    private fun catName(a: App): String {
        val p = a.cn.packageName.lowercase(); val l = a.orig.lowercase()
        fun has(vararg k: String) = k.any { p.contains(it) || l.contains(it) }
        return when {
            has("settings") -> "Settings"
            a.cat == ApplicationInfo.CATEGORY_GAME -> "Games"
            a.cat == ApplicationInfo.CATEGORY_SOCIAL ||
                has("dialer", "phone", "contacts", "message", "sms", "mms", "mail", "messenger", "whatsapp",
                    "telegram", "discord", "signal", "viber", "chat", "meet", "zoom", "skype") -> "Communication"
            a.cat == ApplicationInfo.CATEGORY_VIDEO ||
                has("video", "youtube", "netflix", "twitch", "tiktok", "movie") -> "Video"
            a.cat == ApplicationInfo.CATEGORY_AUDIO || a.cat == ApplicationInfo.CATEGORY_IMAGE ||
                has("music", "audio", "podcast", "spotify", "gallery", "photo", "camera", "recorder", "radio") -> "Media"
            else -> "Utilities"
        }
    }

    private fun buildLibrary() {
        closeFolder(false)
        libBody.removeAllViews()
        val q = search.text.toString().trim().lowercase()
        if (q.isNotEmpty()) {
            val g = GridLayout(this).apply { columnCount = prefs.cols }
            apps.filter { it.label.lowercase().contains(q) }.forEachIndexed { i, a ->
                g.addView(cell(a, true, { v -> launch(a, v) }, { libMenu(a) }),
                    GridLayout.LayoutParams(GridLayout.spec(i / prefs.cols), GridLayout.spec(i % prefs.cols, 1f)).apply { width = 0 })
            }
            libBody.addView(g, MATCH, WRAP); return
        }
        val g = GridLayout(this).apply { columnCount = 4 }
        var i = 0
        val folders = ArrayList<Pair<String, List<App>>>()
        val rec = prefs.recents().mapNotNull { k -> apps.find { it.key == k } }
        if (rec.isNotEmpty()) folders.add("Suggestions" to rec)
        val newest = apps.sortedByDescending { installTime(it.cn.packageName) }.take(8)
        if (newest.isNotEmpty()) folders.add("Recently Added" to newest)
        val groups = apps.groupBy { catName(it) }
        for (n in catOrder) groups[n]?.let { folders.add(n to it) }
        for ((name, list) in folders) {
            g.addView(card(name, list), GridLayout.LayoutParams(GridLayout.spec(i / 4), GridLayout.spec(i % 4, 1f)).apply {
                width = 0; setMargins(dp(12), dp(16), dp(12), dp(8))
            }); i++
        }
        libBody.addView(g, MATCH, WRAP)
    }

    private fun card(name: String, list: List<App>): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val tile = GridLayout(this).apply { columnCount = 2; setPadding(dp(8), dp(8), dp(8), dp(8)); background = rounded(Color.argb(70, 255, 255, 255), dp(19)) }
        list.take(4).forEachIndexed { i, a ->
            tile.addView(ImageView(this).apply { setImageDrawable(dr(a)) },
                GridLayout.LayoutParams(GridLayout.spec(i / 2), GridLayout.spec(i % 2)).apply { width = dp(40); height = dp(40); setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        val lab = TextView(this).apply { text = name; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) }
        tile.setOnClickListener { openFolderPanel(name, list, tile, lab, dp(19).toFloat(), null) }
        box.addView(tile, dp(112), dp(112))
        box.addView(lab)
        return box
    }

    private fun buildFolderLayer(): View {
        folderLayer = FrameLayout(this).apply { visibility = View.GONE }
        folderScrim = View(this).apply {
            setBackgroundColor(Color.argb(45, 0, 0, 0)); alpha = 0f
            setOnClickListener { closeFolder(true) }
        }
        folderLayer.addView(folderScrim, MATCH, MATCH)
        folderBg = MorphBg(this)
        folderLayer.addView(folderBg, MATCH, MATCH)
        folderTitle = TextView(this).apply { setTextColor(Color.WHITE); textSize = 30f; gravity = Gravity.CENTER }
        folderTitle.setOnClickListener { curFolderId?.let { renameFolder(it) } }
        folderPanel = ScrollView(this).apply { isClickable = true; setPadding(dp(16), dp(16), dp(16), dp(16)) }
        folderGrid = GridLayout(this).apply { columnCount = 4 }
        folderPanel.addView(folderGrid)
        folderBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        folderBox.addView(folderTitle, WRAP, WRAP)
        folderBox.addView(folderPanel, LinearLayout.LayoutParams(dp(200), dp(200)).apply { topMargin = dp(20) })
        folderLayer.addView(folderBox, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        return folderLayer
    }

    // Shared by library categories (folderId == null) and home-screen folders
    private fun openFolderPanel(name: String, list: List<App>, tile: ViewGroup, label: View, radius0: Float, folderId: String?) {
        if (folderOpen) return
        folderAnim?.cancel()
        folderTile?.alpha = 1f; folderLabel?.alpha = 1f
        folderOpen = true; folderTile = tile; folderLabel = label
        curFolderId = folderId; gRadius0 = radius0
        folderUnder = if (libOpen) library else homeLayer
        folderBlurBase = if (libOpen) 1f else 0f
        folderTitle.text = name
        val minCw = dp(prefs.iconDp) + dp(12)
        val side0 = minOf(4 * dp(104) + dp(32), (root.height * 0.78f).toInt(), (root.width * 0.92f).toInt())
        val cw = maxOf((side0 - dp(32)) / 4, minCw)
        val side = 4 * cw + dp(32)
        folderGrid.removeAllViews(); folderCells.clear()
        list.forEachIndexed { i, a ->
            val c = cell(a, true, { v -> launch(a, v); closeFolder(false) },
                { if (folderId != null) folderAppMenu(a, folderId) else libMenu(a) })
            folderCells.add(c)
            folderGrid.addView(c, GridLayout.LayoutParams(GridLayout.spec(i / 4), GridLayout.spec(i % 4)).apply { width = cw })
        }
        folderPanel.layoutParams = LinearLayout.LayoutParams(side, side).apply { topMargin = dp(20) }
        folderPanel.scrollTo(0, 0)
        folderP = 0f
        folderBox.alpha = 0f
        folderLayer.visibility = View.VISIBLE
        folderBox.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                folderBox.viewTreeObserver.removeOnGlobalLayoutListener(this)
                prepareFolder(); applyFolder(0f)
                folderBox.alpha = 1f
                tile.alpha = 0f; folderLabel?.alpha = 0f
                setFolderClip(false)
                runFolder(true)
            }
        })
    }

    private fun setFolderClip(clip: Boolean) {
        folderLayer.clipChildren = clip; folderBox.clipChildren = clip
        folderPanel.clipChildren = clip; folderPanel.clipToPadding = clip; folderGrid.clipChildren = clip
    }

    // Measure where everything starts (inside the tile) and where it ends (in the panel)
    private fun prepareFolder() {
        val tile = folderTile as? ViewGroup ?: return
        val label = folderLabel ?: return
        val lo = IntArray(2); folderLayer.getLocationOnScreen(lo)
        fun rect(v: View): RectF {
            val l = IntArray(2); v.getLocationOnScreen(l)
            val x = (l[0] - lo[0]).toFloat(); val y = (l[1] - lo[1]).toFloat()
            return RectF(x, y, x + v.width, y + v.height)
        }
        folderTitle.translationX = 0f; folderTitle.translationY = 0f; folderTitle.scaleX = 1f; folderTitle.scaleY = 1f
        for (c in folderCells) { c.translationX = 0f; c.translationY = 0f; c.scaleX = 1f; c.scaleY = 1f; c.alpha = 1f }
        gTile = rect(tile); gPanel = rect(folderPanel)
        gMini = tile.childCount
        val lt = (label as? TextView)?.textSize ?: 0f
        gTs0 = if (lt > 0f) lt / folderTitle.textSize else 0.43f
        val tr = rect(folderTitle); val lr = rect(label)
        gTitle[0] = lr.centerX() - tr.centerX(); gTitle[1] = lr.centerY() - tr.centerY()
        gCells.clear()
        folderCells.forEachIndexed { i, c ->
            val cg = c as ViewGroup
            val ic = cg.getChildAt(0)
            cg.pivotX = ic.left + ic.width / 2f; cg.pivotY = ic.top + ic.height / 2f
            val fr = rect(ic)
            val sx: Float; val sy: Float; val s0: Float
            if (i < tile.childCount) {
                val m = rect(tile.getChildAt(i))
                sx = m.centerX(); sy = m.centerY(); s0 = m.width() / fr.width()
            } else { sx = gTile.centerX(); sy = gTile.centerY(); s0 = 0.3f }
            val inside = gPanel.contains(fr.centerX(), fr.centerY())
            gCells.add(floatArrayOf(sx - fr.centerX(), sy - fr.centerY(), s0, if (inside) 1f else 0f))
        }
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    // p = 0: looks exactly like the little folder tile. p = 1: the open panel.
    private fun applyFolder(p: Float) {
        folderP = p
        val q = p.coerceIn(0f, 1f); val m = 1f - q
        folderBg.rect.set(lerp(gTile.left, gPanel.left, q), lerp(gTile.top, gPanel.top, q),
            lerp(gTile.right, gPanel.right, q), lerp(gTile.bottom, gPanel.bottom, q))
        folderBg.radius = lerp(gRadius0, dp(28).toFloat(), q)
        folderBg.invalidate()
        folderScrim.alpha = q
        folderUnder?.let { u ->
            u.alpha = 1f - q
            if (Build.VERSION.SDK_INT >= 31)
                u.setRenderEffect(if (q > 0.02f) RenderEffect.createBlurEffect(24f * q, 24f * q, Shader.TileMode.CLAMP) else null)
        }
        wallBlur.alpha = maxOf(folderBlurBase, q)
        folderTitle.translationX = m * gTitle[0]; folderTitle.translationY = m * gTitle[1]
        val ts = lerp(gTs0, 1f, q); folderTitle.scaleX = ts; folderTitle.scaleY = ts
        val la = ((q - 0.5f) / 0.5f).coerceIn(0f, 1f)
        folderCells.forEachIndexed { i, c ->
            val g = gCells.getOrNull(i) ?: return@forEachIndexed
            c.translationX = m * g[0]; c.translationY = m * g[1]
            val sc = lerp(g[2], 1f, q); c.scaleX = sc; c.scaleY = sc
            c.alpha = when {
                q >= 1f -> 1f
                g[3] == 0f -> 0f
                i < gMini -> 1f
                else -> (q * 2.5f).coerceIn(0f, 1f)
            }
            (c as ViewGroup).getChildAt(1).alpha = la
        }
    }

    private fun runFolder(open: Boolean) {
        folderAnim?.cancel()
        val va = ValueAnimator.ofFloat(folderP, if (open) 1f else 0f)
        va.duration = if (open) 440 else 360
        va.interpolator = PathInterpolator(0.22f, 1f, 0.36f, 1f)   // smooth ease-out
        va.addUpdateListener { applyFolder(it.animatedValue as Float) }
        va.addListener(object : AnimatorListenerAdapter() {
            var cancelled = false
            override fun onAnimationCancel(a: Animator) { cancelled = true }
            override fun onAnimationEnd(a: Animator) {
                if (cancelled) return
                if (open) setFolderClip(true) else hideFolderNow()
            }
        })
        folderAnim = va
        va.start()
    }

    private fun hideFolderNow() {
        folderAnim?.cancel()
        folderUnder?.let { u ->
            u.alpha = 1f
            if (Build.VERSION.SDK_INT >= 31) u.setRenderEffect(null)
        }
        wallBlur.alpha = folderBlurBase
        folderLayer.visibility = View.GONE
        folderTile?.alpha = 1f; folderLabel?.alpha = 1f
        folderP = 0f
    }

    private fun closeFolder(animate: Boolean) {
        if (!folderOpen) return
        folderOpen = false
        if (animate) { setFolderClip(false); runFolder(false) } else hideFolderNow()
    }

    private fun menu(a: App, items: List<Pair<String, () -> Unit>>) {
        Ios.sheet(this, a.label, (items + iconItems(a)).map { (label, action) -> Ios.Item(label, label.startsWith("Remove"), action) })
    }

    private fun info(a: App) = startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.cn.packageName)))

    private fun homeMenu(a: App) = menu(a, listOf(
        "Edit home screen" to { enterEdit() },
        "Rename" to { rename(a) },
        "Remove from home/dock" to { removeFromHome(a.key); prefs.dock = prefs.dock - a.key; buildHome() },
        "App info" to { info(a) }))

    private fun folderMenu(id: String) {
        Ios.sheet(this, prefs.folderName(id), listOf(
            Ios.Item("Rename") { renameFolder(id) },
            Ios.Item("Edit Home Screen") { enterEdit() },
            Ios.Item("Remove Folder", true) { removeFolder(id) }))
    }

    private fun folderAppMenu(a: App, id: String) = menu(a, listOf(
        "Move out of folder" to { moveOutOfFolder(a.key, id) },
        "Rename" to { rename(a) },
        "App info" to { info(a) }))

    private fun moveOutOfFolder(key: String, id: String) {
        val rest = prefs.folderApps(id) - key
        val sl = slots(); val cov = coveredSlots()
        val e = sl.indices.firstOrNull { sl[it].isEmpty() && it !in cov }
        if (e == null) { Toast.makeText(this, "Home screen is full", Toast.LENGTH_SHORT).show(); return }
        sl[e] = key
        if (rest.isEmpty()) { val fi = sl.indexOf(id); if (fi >= 0) sl[fi] = ""; prefs.deleteFolder(id) } else prefs.setFolderApps(id, rest)
        prefs.home = sl
        popKey = key
        buildHome()
    }

    private fun removeFolder(id: String) {
        prefs.home = slots().map { if (it == id) "" else it }
        prefs.deleteFolder(id)
        buildHome()
    }

    private fun renameFolder(id: String) {
        Ios.input(this, "Folder Name", null, prefs.folderName(id)) { text ->
            val n = text.trim().ifEmpty { "Folder" }
            prefs.setFolderName(id, n)
            if (curFolderId == id) { folderTitle.text = n; (folderLabel as? TextView)?.text = n }
        }
    }

    private fun libMenu(a: App) = menu(a, listOf(
        "Add to home screen" to { addToHome(a.key); buildHome() },
        "Add to dock" to { removeFromHome(a.key); if (a.key !in prefs.dock) prefs.dock = prefs.dock + a.key; buildHome() },
        "Rename" to { rename(a) },
        "App info" to { info(a) }))

    private fun rename(a: App) {
        Ios.input(this, "Rename", "Leave empty to reset the name", a.label) { text ->
            prefs.setLabel(a.key, text.trim().ifEmpty { null }); reload()
        }
    }
}
